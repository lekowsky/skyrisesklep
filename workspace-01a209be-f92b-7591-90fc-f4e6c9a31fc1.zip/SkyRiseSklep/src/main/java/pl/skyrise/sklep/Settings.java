package pl.skyrise.sklep;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Wszystkie wartości z config.yml w jednym miejscu. */
public final class Settings {

    /** Dawne domyślne nazwy przycisków - podmieniamy tylko je, własne nazwy admina zostają. */
    private static final Set<String> LEGACY_CASH_NAMES = Set.of(
            "&a&lZAPŁAĆ &e{total}", "&a&lGOTÓWKĄ &e{total}", "&a&lZAPŁAĆ GOTÓWKĄ &e<{total}>");
    private static final Set<String> LEGACY_CARD_NAMES = Set.of(
            "&a&lKARTĄ &e{total}", "&a&lZAPŁAĆ KARTĄ &e<{total}>");

    private static final String CASH_NAME = "&a&lZAPŁAĆ GOTÓWKĄ &e{total}";
    private static final String CARD_NAME = "&a&lZAPŁAĆ KARTĄ &e{total}";

    private final SkyRiseSklep plugin;
    private FileConfiguration cfg;

    public String basketNexoId;
    public String basketFallbackMaterial;
    public int basketFallbackCmd;
    public String basketFallbackItemModel;
    public String basketName;
    public boolean basketUnique;
    public boolean basketRequired;
    public boolean basketRequireInHand;
    public boolean basketAllowOffhand;
    public boolean basketLockToInventory;
    public boolean basketRemoveAfterPurchase;
    public boolean basketReturnOnReclick;
    public boolean basketReturnResetsCart;
    public int basketAutoRemoveDistance;
    public int basketAutoRemoveCheckSeconds;

    public boolean cartEnabled;
    public boolean cartShowOnBasket;
    public boolean cartHideAfterPurchase;
    public boolean cartToggleCommand;
    public boolean cartForceTabVisible;
    public String cartTitle;
    public int cartBlankLines;
    public String cartEmptyLine;
    public String cartItemLine;
    public String cartMoreLine;
    public String cartTotalLine;
    public int cartMaxItems;
    public boolean cartBukkitFallback;
    public boolean cartClearOnNewBasket;

    public boolean taxEnabled;
    public double taxRate;
    public String taxReceiver;
    public boolean taxLog;

    public String shopTitle;
    public String editorTitle;
    public double defaultPrice;
    public int bulkAmount;
    public int shelfRadius;
    public String fillerItem;
    public boolean logPurchases;
    public List<String> priceLore;
    public List<String> cartLore;
    public List<String> editorInfo;

    public String checkoutMode;
    public String checkoutTitle;
    public int checkoutRadius;
    public boolean checkoutRequireBasket;
    public boolean checkoutClearAfterPayment;
    public String checkoutPayButton;
    public String checkoutCardButton;
    public String checkoutCashMaterial;
    public String checkoutCardMaterial;
    public boolean checkoutCardEnabled;
    public String checkoutClearButton;
    public String checkoutCloseButton;
    public String checkoutInfoButton;
    public List<String> checkoutItemLore;
    public List<String> checkoutRemoveLore;

    public boolean promoEnabled;
    public String promoMode;
    public int promoCheckSeconds;
    public String promoDailyAt;
    public int promoAutoMinItems;
    public int promoAutoMaxItems;
    public boolean promoAllShelves;
    public int promoAutoMin;
    public int promoAutoMax;
    public int promoLuckyChance;
    public int promoLuckyPercent;
    public int promoManualPercent;
    public int promoManualMinutes;
    public boolean promoAnnounce;
    public boolean promoPersist;
    public List<String> promoDays;
    public List<String> promoLore;

    public String adminTitle;
    public String adminShelfTitle;
    public String adminPromoTitle;
    public String adminNewShelf;
    public String adminPromotions;
    public String adminReload;
    public String adminClose;
    public String adminBack;
    public String adminEditItems;
    public String adminDefaultPrice;
    public String adminPromoAll;
    public String adminClearPromos;
    public String adminAddTarget;
    public String adminRemoveTarget;
    public String adminDeleteShelf;
    public String adminRollNow;
    public String adminClearAll;
    public String adminInfo;
    public String adminBasketPoint;
    public String adminCheckoutPoint;
    public int guiClickCooldownMs;

    public boolean pinEnabled;
    public int pinLength;
    public int pinMaxAttempts;
    public String pinTitle;
    public String pinBody;
    public String pinLabel;
    public String pinSubmit;
    public String pinCancel;

    public String economyMode;
    public boolean fallbackFree;
    public String currencySymbol;
    public String xpLabel;

    public boolean bankRequireCard;
    public boolean bankCardInHand;
    public boolean bankAllowForeignCard;
    public String bankReason;
    public String bankFallback;

    public String basketSound;
    public String openSound;
    public String buySound;
    public String errorSound;

    public long selectionTimeoutMs;

    public Settings(SkyRiseSklep plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        cfg = plugin.getConfig();

        basketNexoId = str("basket.nexo-id", "skyrise_koszyk");
        basketFallbackMaterial = str("basket.fallback-material", "HOPPER");
        basketFallbackCmd = integer("basket.fallback-custom-model-data", 0);
        basketFallbackItemModel = str("basket.fallback-item-model", "");
        basketName = str("basket.name", "&aKoszyk na zakupy");
        basketUnique = bool("basket.unique", true);
        basketRequired = bool("basket.require-to-open-shelf", true);
        basketRequireInHand = bool("basket.require-in-hand", true);
        basketAllowOffhand = bool("basket.allow-offhand", false);
        basketLockToInventory = bool("basket.lock-to-inventory", true);
        basketRemoveAfterPurchase = bool("basket.remove-after-purchase", true);
        basketReturnOnReclick = bool("basket.return-on-reclick", true);
        basketReturnResetsCart = bool("basket.return-resets-cart", true);
        basketAutoRemoveDistance = Math.max(0, integer("basket.auto-remove-distance", 100));
        basketAutoRemoveCheckSeconds = Math.max(1, Math.min(60, integer("basket.auto-remove-check-seconds", 2)));

        cartEnabled = bool("cart.enabled", false);
        cartShowOnBasket = bool("cart.show-on-basket", true);
        cartHideAfterPurchase = bool("cart.hide-after-purchase", true);
        cartToggleCommand = bool("cart.toggle-command", true);
        cartForceTabVisible = bool("cart.force-tab-visible", true);
        cartTitle = str("cart.title", "Twój koszyk");
        cartBlankLines = Math.max(0, Math.min(10, integer("cart.blank-lines", 2)));
        cartEmptyLine = str("cart.empty-line", "&7&oKoszyk jest pusty");
        cartItemLine = str("cart.item-line", "&f{amount}x &7{item} &8- &e{price}");
        cartMoreLine = str("cart.more-line", "&7... i jeszcze &f{count}");
        cartTotalLine = str("cart.total-line", "&7Suma: &e{total}");
        cartMaxItems = Math.max(1, Math.min(15, integer("cart.max-items", 10)));
        cartBukkitFallback = bool("cart.bukkit-fallback", true);
        cartClearOnNewBasket = bool("cart.clear-on-new-basket", true);

        taxEnabled = bool("tax.enabled", true);
        taxRate = Math.max(0, dbl("tax.rate", 0.10));
        taxReceiver = str("tax.receiver", "");
        taxLog = bool("tax.log", true);

        shopTitle = str("shop.title", "&8| &aSklep &7- &f{shelf}");
        editorTitle = str("shop.editor-title", "&8| &cEdytor &7- &f{shelf}");
        defaultPrice = Math.max(0, dbl("shop.default-price", 10.0));
        bulkAmount = Math.max(1, integer("shop.bulk-amount", 16));
        shelfRadius = Math.max(0, Math.min(8, integer("shop.shelf-radius", 1)));
        fillerItem = str("shop.filler-item", "GRAY_STAINED_GLASS_PANE");
        logPurchases = bool("shop.log-purchases", true);
        priceLore = list("shop.price-lore", List.of("&7Cena: &e{price}"));
        cartLore = list("shop.cart-lore", List.of("&7Cena: &e{price}"));
        editorInfo = list("gui.editor-info", List.of("&7Włóż przedmioty do 45 górnych slotów."));

        String mode = str("checkout.mode", "CHECKOUT").toUpperCase(Locale.ROOT);
        checkoutMode = mode.equals("INSTANT") ? "INSTANT" : "CHECKOUT";
        checkoutTitle = str("checkout.title", "&8| &eKasa &7- &fPodsumowanie");
        checkoutRadius = Math.max(1, integer("checkout.radius", 6));
        checkoutRequireBasket = bool("checkout.require-basket", true);
        checkoutClearAfterPayment = bool("checkout.clear-after-payment", true);
        checkoutPayButton = str("checkout.pay-button", CASH_NAME);
        if (LEGACY_CASH_NAMES.contains(checkoutPayButton)) checkoutPayButton = CASH_NAME;
        checkoutCardButton = str("checkout.card-button", CARD_NAME);
        if (LEGACY_CARD_NAMES.contains(checkoutCardButton)) checkoutCardButton = CARD_NAME;
        checkoutCashMaterial = str("checkout.cash-material", "GOLD_BLOCK");
        checkoutCardMaterial = str("checkout.card-material", "LAPIS_BLOCK");
        checkoutCardEnabled = bool("checkout.card-enabled", true);
        checkoutClearButton = str("checkout.clear-button", "&cWyczyść koszyk");
        checkoutCloseButton = str("checkout.close-button", "&cZamknij");
        checkoutInfoButton = str("checkout.info-button", "&ePodsumowanie koszyka");
        checkoutItemLore = list("checkout.item-lore", List.of("&7Ilość: &f{amount}", "&7Wartość: &e{price}"));
        checkoutRemoveLore = list("checkout.remove-lore",
                List.of("&7LPM: &cusuń 1 sztukę", "&7PPM / Shift+LPM: &cusuń pozycję"));

        pinEnabled = bool("checkout.pin.enabled", true);
        pinLength = Math.max(0, Math.min(16, integer("checkout.pin.length", 0)));
        pinMaxAttempts = Math.max(1, Math.min(20, integer("checkout.pin.max-attempts", 3)));
        pinTitle = str("checkout.pin.title", "&8| &aPIN karty");
        pinBody = str("checkout.pin.body", "&7Wpisz PIN, aby zapłacić &e{total} &7kartą &f{card}&7.");
        pinLabel = str("checkout.pin.label", "&7PIN karty");
        pinSubmit = str("checkout.pin.submit", "&aZapłać kartą");
        pinCancel = str("checkout.pin.cancel", "&cAnuluj");

        promoEnabled = bool("promotions.enabled", true);
        promoMode = str("promotions.mode", "AUTO").toUpperCase(Locale.ROOT);
        promoCheckSeconds = Math.max(1, Math.min(300, integer("promotions.check-seconds", 30)));
        promoDailyAt = str("promotions.auto.daily-at", "06:00");
        promoAutoMinItems = Math.max(1, Math.min(45, integer("promotions.auto.min-items", 2)));
        promoAutoMaxItems = Math.max(promoAutoMinItems,
                Math.min(45, integer("promotions.auto.max-items", 8)));
        promoAllShelves = bool("promotions.auto.all-shelves", true);
        promoAutoMin = Math.max(1, Math.min(95, integer("promotions.auto.min-percent", 10)));
        promoAutoMax = Math.max(promoAutoMin, Math.min(95, integer("promotions.auto.max-percent", 30)));
        promoLuckyChance = Math.max(0, Math.min(100, integer("promotions.auto.lucky-chance", 20)));
        promoLuckyPercent = Math.max(0, Math.min(95, integer("promotions.auto.lucky-percent", 15)));
        promoManualPercent = Math.max(1, Math.min(95, integer("promotions.manual-percent", 20)));
        promoManualMinutes = Math.max(1, integer("promotions.manual-minutes", 30));
        promoAnnounce = bool("promotions.announce", true);
        promoPersist = bool("promotions.persist", true);
        promoDays = list("promotions.auto.days", List.of());
        promoLore = list("promotions.lore", List.of("&c&m{old}&r &a&l-{percent}% &7(&f{left}&7)"));

        adminTitle = str("gui.admin.title", "&8| &cPanel admina");
        adminShelfTitle = str("gui.admin.shelf-title", "&8| &cRegał &7- &f{shelf}");
        adminPromoTitle = str("gui.admin.promo-title", "&8| &aPromocje");
        adminNewShelf = str("gui.admin.new-shelf", "&a&lNOWY REGAŁ");
        adminPromotions = str("gui.admin.promotions", "&a&lPROMOCJE");
        adminReload = str("gui.admin.reload", "&e&lPRZEŁADUJ");
        adminClose = str("gui.admin.close", "&cZAMKNIJ");
        adminBack = str("gui.admin.back", "&cWRÓĆ");
        adminEditItems = str("gui.admin.edit-items", "&aEDYTUJ OFERTĘ");
        adminDefaultPrice = str("gui.admin.default-price", "&eCENA DOMYŚLNA");
        adminPromoAll = str("gui.admin.promo-all", "&cPROMOCJA NA REGAŁ");
        adminClearPromos = str("gui.admin.clear-promos", "&7WYCZYŚĆ PROMOCJE");
        adminAddTarget = str("gui.admin.add-target", "&aDODAJ PUNKT");
        adminRemoveTarget = str("gui.admin.remove-target", "&cUSUŃ PUNKT");
        adminDeleteShelf = str("gui.admin.delete-shelf", "&4USUŃ REGAŁ");
        adminRollNow = str("gui.admin.roll-now", "&a&lLOSUJ TERAZ");
        adminClearAll = str("gui.admin.clear-all", "&cWYCZYŚĆ WSZYSTKIE");
        adminInfo = str("gui.admin.info", "&eINFORMACJE");
        adminBasketPoint = str("gui.admin.basket-point", "&aPUNKT KOSZYKA");
        adminCheckoutPoint = str("gui.admin.checkout-point", "&ePUNKT KASY");
        guiClickCooldownMs = Math.max(0, Math.min(5000, integer("gui.click-cooldown-ms", 350)));

        economyMode = str("economy.mode", "BANK").toUpperCase(Locale.ROOT);
        fallbackFree = bool("economy.fallback-free", true);
        currencySymbol = str("economy.currency-symbol", "zł");
        xpLabel = str("economy.xp-label", "poziomów XP");

        bankRequireCard = bool("economy.bank.require-card", true);
        bankCardInHand = bool("economy.bank.card-in-hand", false);
        bankAllowForeignCard = bool("economy.bank.allow-foreign-card", false);
        bankReason = str("economy.bank.reason", "SkyRiseSklep - zakupy");
        bankFallback = str("economy.bank.fallback", "VAULT").toUpperCase(Locale.ROOT);

        basketSound = str("sounds.basket", "entity.item.pickup");
        openSound = str("sounds.open", "block.chest.open");
        buySound = str("sounds.buy", "entity.villager.yes");
        errorSound = str("sounds.error", "entity.villager.no");

        selectionTimeoutMs = Math.max(5, integer("selection-timeout-seconds", 60)) * 1000L;
    }

    public Material fillerMaterial() {
        Material m = Material.matchMaterial(fillerItem);
        if (m == null || m.isAir()) return Material.GRAY_STAINED_GLASS_PANE;
        return m;
    }

    private String str(String path, String def) {
        String v = cfg.getString(path, def);
        return v == null ? def : v;
    }

    private boolean bool(String path, boolean def) {
        return cfg.getBoolean(path, def);
    }

    private double dbl(String path, double def) {
        return cfg.getDouble(path, def);
    }

    private int integer(String path, int def) {
        return cfg.getInt(path, def);
    }

    private List<String> list(String path, List<String> def) {
        List<String> v = cfg.getStringList(path);
        return v == null || v.isEmpty() ? new ArrayList<>(def) : new ArrayList<>(v);
    }
}
