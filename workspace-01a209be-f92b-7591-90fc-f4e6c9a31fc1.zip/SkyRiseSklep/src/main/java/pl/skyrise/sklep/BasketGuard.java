package pl.skyrise.sklep;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Koszyk może istnieć wyłącznie w ekwipunku właściciela (sloty 0-35).
 * Blokuje: skrzynie, enderchesty, shulkerboxy, bundle, zbroję, drugą rękę,
 * wyrzucenie, podniesienie przez kogoś innego, postawienie jako blok,
 * przekazanie encji (ramka, stojak, mebel) oraz przesunięcie przez hopper.
 */
public final class BasketGuard implements Listener {

    private final SkyRiseSklep plugin;
    private final Map<UUID, Long> lastWarning = new ConcurrentHashMap<>();

    public BasketGuard(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    private boolean locked() {
        return plugin.settings().basketLockToInventory;
    }

    private boolean basket(ItemStack item) {
        return plugin.baskets().isBasket(item);
    }

    private void deny(Cancellable event, Player player) {
        event.setCancelled(true);
        if (player == null) return;
        long now = System.currentTimeMillis();
        Long last = lastWarning.get(player.getUniqueId());
        if (last != null && now - last < 2000L) return;
        lastWarning.put(player.getUniqueId(), now);
        plugin.messages().send(player, "basket-locked");
    }

    private String owner(ItemStack item) {
        if (item == null || item.isEmpty()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer()
                .get(SkyRiseSklep.BASKET_OWNER_KEY, PersistentDataType.STRING);
    }

    // ------------------------------------------------------------ KLIKANIE W GUI

    private boolean involves(InventoryClickEvent event) {
        if (basket(event.getCursor()) || basket(event.getCurrentItem())) return true;
        if (event.getAction() == InventoryAction.HOTBAR_SWAP) {
            int button = event.getHotbarButton();
            if (button >= 0) {
                ItemStack hotbar = event.getView().getBottomInventory().getItem(button);
                if (basket(hotbar)) return true;
            }
        }
        return false;
    }

    private boolean blocked(InventoryClickEvent event) {
        InventoryAction action = event.getAction();
        if (action == null) return true;
        String name = action.name();
        if (name.startsWith("DROP_") || name.contains("BUNDLE")) return true;
        if (action == InventoryAction.CLONE_STACK || action == InventoryAction.UNKNOWN) return true;

        Inventory clicked = event.getClickedInventory();
        if (clicked == null) return false;
        if (!(clicked instanceof PlayerInventory)) return true; // skrzynia, enderchest, shulker, GUI, crafting
        if (event.getSlot() >= 36) return true;                 // zbroja (36-39) i druga ręka (40)

        InventoryType.SlotType type = event.getSlotType();
        if (type == InventoryType.SlotType.ARMOR
                || type == InventoryType.SlotType.CRAFTING
                || type == InventoryType.SlotType.RESULT
                || type == InventoryType.SlotType.FUEL
                || type == InventoryType.SlotType.OUTSIDE) return true;

        // Shift-klik koszykiem z własnego ekwipunku przy otwartym kontenerze
        // przeniósłby go do tego kontenera.
        if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY
                && !(event.getView().getTopInventory() instanceof PlayerInventory)
                && basket(event.getCurrentItem())) return true;
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onClick(InventoryClickEvent event) {
        if (!locked() || !(event.getWhoClicked() instanceof Player player)) return;
        if (!involves(event)) return;
        if (blocked(event)) deny(event, player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onDrag(InventoryDragEvent event) {
        if (!locked() || !(event.getWhoClicked() instanceof Player player)) return;
        boolean involved = basket(event.getOldCursor());
        if (!involved) {
            for (ItemStack item : event.getNewItems().values()) {
                if (basket(item)) {
                    involved = true;
                    break;
                }
            }
        }
        if (!involved) return;

        InventoryView view = event.getView();
        for (int raw : event.getRawSlots()) {
            Inventory inv = view.getInventory(raw);
            if (inv == null || !(inv instanceof PlayerInventory)) {
                deny(event, player);
                return;
            }
            int slot = view.convertSlot(raw);
            if (slot < 0 || slot >= 36) {
                deny(event, player);
                return;
            }
        }
    }

    // ------------------------------------------------------------ POZA EKWIPUNKIEM

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        if (!locked()) return;
        if (basket(event.getMainHandItem()) || basket(event.getOffHandItem())) {
            deny(event, event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onDrop(PlayerDropItemEvent event) {
        if (!locked()) return;
        if (basket(event.getItemDrop().getItemStack())) deny(event, event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onPlace(BlockPlaceEvent event) {
        if (!locked()) return;
        if (basket(event.getItemInHand())) deny(event, event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onPickup(EntityPickupItemEvent event) {
        if (!locked()) return;
        ItemStack item = event.getItem().getItemStack();
        if (!basket(item)) return;
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player)) {
            deny(event, null);
            return;
        }
        String owner = owner(item);
        if (owner == null || !owner.equals(player.getUniqueId().toString())) {
            deny(event, player);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        if (!locked()) return;
        Player player = event.getPlayer();
        boolean hasBasket = basket(player.getInventory().getItemInMainHand())
                || basket(player.getInventory().getItemInOffHand());
        if (!hasBasket) return;

        String key = Targets.entity(event.getRightClicked());
        if (plugin.data().basketPoints().contains(key)) return;
        if (plugin.data().checkoutPoints().contains(key)) return;
        if (plugin.data().findShelfByTarget(key) != null) return;
        if (plugin.listeners().hasSelection(player)) return;
        deny(event, player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onArmorStand(PlayerArmorStandManipulateEvent event) {
        if (!locked()) return;
        if (basket(event.getPlayerItem()) || basket(event.getArmorStandItem())) {
            deny(event, event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onHopper(InventoryMoveItemEvent event) {
        if (!locked()) return;
        if (basket(event.getItem()) && !(event.getDestination() instanceof PlayerInventory)) {
            deny(event, null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onDeath(PlayerDeathEvent event) {
        if (!locked()) return;
        try {
            Iterator<ItemStack> iterator = event.getDrops().iterator();
            while (iterator.hasNext()) {
                ItemStack drop = iterator.next();
                if (basket(drop)) {
                    iterator.remove();
                    event.getItemsToKeep().add(drop);
                }
            }
        } catch (Throwable ignored) {
            // koszyk i tak nie powinien wypaść - nie psuj śmierci gracza
        }
    }
}
