package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Scoreboard koszyka przez API pluginu TAB (NEZNAMY). Cała integracja przez
 * refleksję, więc plugin działa też bez TAB-a i przy wyłączonym scoreboardzie
 * TAB-a (wtedy używa zwykłego scoreboardu Bukkita).
 *
 * TAB zwraca null z getScoreboardManager(), gdy w jego configu jest
 * scoreboard.enabled: false. Z kolei przy hidden-by-default: true API
 * showScoreboard() nie wyśle planszy, bo hasScoreboardVisible() == false -
 * dlatego na czas koszyka wymuszamy widoczność i przywracamy poprzedni stan.
 */
public final class TabHook {

    private final SkyRiseSklep plugin;

    private boolean available;
    private boolean tabPresent;
    private Object api;
    private Object manager;
    private Method getPlayer;
    private Method createScoreboard;
    private Method showScoreboard;
    private Method resetScoreboard;
    private Method removeByName;
    private Method removeByBoard;
    private Method hasVisibleMethod;
    private Method setVisibleMethod;

    private final Map<UUID, Object> tabBoards = new ConcurrentHashMap<>();
    private final Map<UUID, Scoreboard> bukkitBoards = new ConcurrentHashMap<>();
    /** Poprzedni stan widoczności TAB-a dla graczy, którym go wymuszamy. */
    private final Map<UUID, Boolean> forcedVisibility = new ConcurrentHashMap<>();
    private boolean warned;

    public TabHook(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    public void init() {
        available = false;
        tabPresent = false;
        api = null;
        manager = null;
        getPlayer = createScoreboard = showScoreboard = resetScoreboard = removeByName = removeByBoard = null;
        hasVisibleMethod = setVisibleMethod = null;
        forcedVisibility.clear();

        try {
            Class<?> apiClass = Class.forName("me.neznamy.tab.api.TabAPI");
            tabPresent = true;
            api = apiClass.getMethod("getInstance").invoke(null);
            if (api == null) return;

            Method getManager = find(api.getClass(), "getScoreboardManager", 0);
            if (getManager == null) return;
            manager = getManager.invoke(api);
            if (manager == null) {
                plugin.getLogger().info("TAB jest, ale ma scoreboard.enabled: false - koszyk użyje scoreboardu Bukkita (to nie jest błąd).");
                return;
            }

            Class<?> tabPlayerClass = null;
            Class<?> boardClass = null;
            try {
                tabPlayerClass = Class.forName("me.neznamy.tab.api.TabPlayer");
                boardClass = Class.forName("me.neznamy.tab.api.scoreboard.Scoreboard");
            } catch (Throwable ignored) {
                // starsza wersja TAB-a - dopasujemy metody po liczbie argumentów
            }

            getPlayer = find(api.getClass(), "getPlayer", 1, UUID.class);
            createScoreboard = find(manager.getClass(), "createScoreboard", 3, String.class, String.class, List.class);
            showScoreboard = tabPlayerClass != null && boardClass != null
                    ? find(manager.getClass(), "showScoreboard", 2, tabPlayerClass, boardClass)
                    : find(manager.getClass(), "showScoreboard", 2);
            resetScoreboard = tabPlayerClass != null
                    ? find(manager.getClass(), "resetScoreboard", 1, tabPlayerClass)
                    : find(manager.getClass(), "resetScoreboard", 1);
            removeByName = find(manager.getClass(), "removeScoreboard", 1, String.class);
            removeByBoard = boardClass != null
                    ? find(manager.getClass(), "removeScoreboard", 1, boardClass)
                    : null;
            hasVisibleMethod = find(manager.getClass(), "hasScoreboardVisible", 1);
            setVisibleMethod = find(manager.getClass(), "setScoreboardVisible", 3);

            available = getPlayer != null && createScoreboard != null && showScoreboard != null;
            if (available) {
                plugin.getLogger().info("Wykryto TAB - scoreboard koszyka będzie wyświetlany przez API TAB.");
                if (plugin.settings().cartForceTabVisible && setVisibleMethod != null) {
                    plugin.getLogger().info("Obsłużony też tryb TAB hidden-by-default: true (wymuszanie widoczności tylko na czas koszyka).");
                }
            } else {
                plugin.getLogger().warning("TAB wykryty, ale API scoreboardu jest niedostępne. Używam scoreboardu Bukkita.");
            }
        } catch (Throwable t) {
            warn(t);
        }
        if (!available && !tabPresent) {
            plugin.getLogger().info("Brak pluginu TAB - koszyk użyje scoreboardu Bukkita.");
        }
    }

    public boolean available() {
        return available;
    }

    /** Opis aktualnego silnika do /srs informacje i logu startowego. */
    public String status() {
        if (!available) {
            return tabPresent ? "Bukkit fallback (scoreboard.enabled: false w TAB)"
                    : "Bukkit fallback (brak pluginu TAB)";
        }
        return setVisibleMethod != null && plugin.settings().cartForceTabVisible
                ? "TAB API (z obsługą hidden-by-default)" : "TAB API";
    }

    public void show(Player player, String title, List<String> lines) {
        show(player, title, lines, 0);
    }

    private void show(Player player, String title, List<String> lines, int attempt) {
        UUID uuid = player.getUniqueId();
        if (available) {
            try {
                Object tabPlayer = getPlayer.invoke(api, uuid);
                if (tabPlayer == null) {
                    if (attempt < 4 && player.isOnline()) {
                        Bukkit.getScheduler().runTaskLater(plugin,
                                () -> show(player, title, lines, attempt + 1), 20L);
                    }
                    return;
                }

                // TAB nie wyśle custom scoreboardu, gdy gracz ma widoczność wyłączoną
                // (hidden-by-default: true albo /sb off). Wymuszamy ją tylko na czas koszyka.
                boolean visible = isVisible(tabPlayer);
                if (!visible) {
                    if (!plugin.settings().cartForceTabVisible || setVisibleMethod == null) {
                        if (plugin.settings().cartBukkitFallback) showBukkit(player, title, lines);
                        return;
                    }
                    forcedVisibility.putIfAbsent(uuid, false);
                    setVisible(tabPlayer, true);
                }

                Object board = tabBoards.get(uuid);
                if (board != null) {
                    Method setLines = find(board.getClass(), "setLines", 1, List.class);
                    if (setLines != null) {
                        setLines.invoke(board, new ArrayList<>(lines));
                        Method setTitle = find(board.getClass(), "setTitle", 1, String.class);
                        if (setTitle != null) setTitle.invoke(board, title);
                        return;
                    }
                    removeBoard(uuid, board);
                }

                String name = boardName(uuid);
                if (removeByName != null) {
                    try {
                        removeByName.invoke(manager, name);
                    } catch (Throwable ignored) {
                        // nazwa mogła nie istnieć
                    }
                }
                Object created = createScoreboard.invoke(manager, name, title, new ArrayList<>(lines));
                if (created == null) {
                    showBukkit(player, title, lines);
                    return;
                }
                tabBoards.put(uuid, created);
                showScoreboard.invoke(manager, tabPlayer, created);
                return;
            } catch (Throwable t) {
                warn(t);
            }
        }
        if (plugin.settings().cartBukkitFallback) showBukkit(player, title, lines);
    }

    public void hide(Player player) {
        UUID uuid = player.getUniqueId();
        if (available) {
            try {
                Object tabPlayer = getPlayer.invoke(api, uuid);
                Boolean previous = forcedVisibility.get(uuid);
                if (tabPlayer != null) {
                    if (previous != null && !previous) {
                        // Najpierw wyłączamy widoczność (TAB usuwa aktywną planszę),
                        // potem wyrejestrowujemy naszą - sendHighestScoreboard() TAB-a
                        // sam sprawdzi widoczność i nie pokaże domyślnego scoreboardu.
                        setVisible(tabPlayer, false);
                        removeByNameOnly(uuid);
                        forcedVisibility.remove(uuid);
                    } else {
                        if (resetScoreboard != null) resetScoreboard.invoke(manager, tabPlayer);
                        Object board = tabBoards.get(uuid);
                        if (board != null) removeBoard(uuid, board);
                    }
                }
            } catch (Throwable t) {
                warn(t);
            }
        } else {
            forcedVisibility.remove(uuid);
        }
        hideBukkit(player);
    }

    private boolean isVisible(Object tabPlayer) {
        if (hasVisibleMethod == null) return true;
        try {
            Object value = hasVisibleMethod.invoke(manager, tabPlayer);
            return !(value instanceof Boolean b) || b;
        } catch (Throwable t) {
            warn(t);
            return true;
        }
    }

    private void setVisible(Object tabPlayer, boolean visible) {
        if (setVisibleMethod == null) return;
        try {
            setVisibleMethod.invoke(manager, tabPlayer, visible, false);
        } catch (Throwable t) {
            warn(t);
        }
    }

    private void removeByNameOnly(UUID uuid) {
        tabBoards.remove(uuid);
        if (removeByName == null) return;
        try {
            removeByName.invoke(manager, boardName(uuid));
        } catch (Throwable ignored) {
            // plansza mogła już zostać wyrejestrowana przez TAB
        }
    }

    private void removeBoard(UUID uuid, Object board) {
        tabBoards.remove(uuid);
        try {
            Method unregister = find(board.getClass(), "unregister", 0);
            if (unregister != null) {
                unregister.invoke(board);
            } else if (removeByBoard != null) {
                removeByBoard.invoke(manager, board);
            } else if (removeByName != null) {
                removeByName.invoke(manager, boardName(uuid));
            }
        } catch (Throwable ignored) {
            // najwyżej stary scoreboard zostanie nadpisany przy następnym show()
        }
    }

    private void showBukkit(Player player, String title, List<String> lines) {
        org.bukkit.scoreboard.ScoreboardManager bukkitManager = Bukkit.getScoreboardManager();
        if (bukkitManager == null) return;
        try {
            Scoreboard board = bukkitBoards.computeIfAbsent(player.getUniqueId(), k -> bukkitManager.getNewScoreboard());
            Objective objective = board.getObjective("srs_cart");
            if (objective == null) {
                objective = board.registerNewObjective("srs_cart", "dummy", Util.color(title));
            } else {
                objective.displayName(Util.color(title));
            }
            objective.setDisplaySlot(DisplaySlot.SIDEBAR);

            for (String entry : new ArrayList<>(board.getEntries())) board.resetScores(entry);

            int score = lines.size();
            for (String line : lines) {
                String entry = "§" + Integer.toHexString(score & 15) + line;
                objective.getScore(entry).setScore(score--);
            }
            player.setScoreboard(board);
        } catch (Throwable t) {
            warn(t);
        }
    }

    private void hideBukkit(Player player) {
        if (bukkitBoards.remove(player.getUniqueId()) == null) return;
        org.bukkit.scoreboard.ScoreboardManager bukkitManager = Bukkit.getScoreboardManager();
        if (bukkitManager != null) player.setScoreboard(bukkitManager.getMainScoreboard());
    }

    private static String boardName(UUID uuid) {
        return "skyrise_koszyk_" + uuid.toString().replace("-", "");
    }

    private static Method find(Class<?> clazz, String name, int paramCount, Class<?>... types) {
        Method byCount = null;
        for (Method method : clazz.getMethods()) {
            if (!method.getName().equals(name) || method.getParameterCount() != paramCount) continue;
            if (byCount == null) byCount = method;
            if (types.length == 0) continue;
            Class<?>[] actual = method.getParameterTypes();
            boolean matches = true;
            for (int i = 0; i < types.length && i < actual.length; i++) {
                if (!types[i].isAssignableFrom(actual[i]) && !actual[i].isAssignableFrom(types[i])) {
                    matches = false;
                    break;
                }
            }
            if (matches) return method;
        }
        return byCount;
    }

    private void warn(Throwable t) {
        if (warned) return;
        warned = true;
        plugin.getLogger().warning("Problem z API TAB (" + t.getClass().getSimpleName()
                + ") - używam scoreboardu Bukkita jako zapasowego.");
    }
}
