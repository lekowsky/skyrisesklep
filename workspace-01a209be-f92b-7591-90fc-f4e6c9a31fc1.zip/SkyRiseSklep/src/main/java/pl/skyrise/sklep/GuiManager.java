package pl.skyrise.sklep;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** GUI dużej skrzynki (54 sloty) dla graczy oraz edytor dla administratora. */
public final class GuiManager {

    public static final int ITEM_SLOTS = 45; // 0-44: przedmioty, 45-53: pasek kontrolny
    public static final int CARD_SLOT = 48;  // płatność kartą (PIN) - tuż obok gotówki
    public static final int CASH_SLOT = 49;  // płatność gotówką

    private final SkyRiseSklep plugin;
    private final Set<UUID> processing = ConcurrentHashMap.newKeySet();

    public GuiManager(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ GRACZ

    public void openShop(Player player, Shelf shelf) {
        ShopHolder holder = new ShopHolder(shelf);
        Inventory inv = Bukkit.createInventory(holder, 54,
                Util.color(Util.replace(plugin.settings().shopTitle, "shelf", shelf.name)));
        holder.setInventory(inv);

        for (int slot = 0; slot < ITEM_SLOTS; slot++) {
            ItemStack base = shelf.items.get(slot);
            if (base != null && !base.isEmpty()) inv.setItem(slot, displayItem(player, shelf, base, slot));
        }
        decorateShop(inv, shelf);
        player.openInventory(inv);
        plugin.sound(player, plugin.settings().openSound);
    }

    private ItemStack displayItem(Player player, Shelf shelf, ItemStack base, int slot) {
        ItemStack item = base.clone();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        double basePrice = shelf.priceFor(slot, plugin.settings().defaultPrice);
        double price = plugin.promotions().apply(player, shelf.name, slot, basePrice);
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        List<String> loreLines = plugin.settings().checkoutMode.equals("CHECKOUT")
                ? plugin.settings().cartLore : plugin.settings().priceLore;
        for (String line : loreLines) {
            lore.add(Util.color(Util.replace(line,
                    "price", plugin.economy().format(price),
                    "old", plugin.economy().format(basePrice),
                    "stack", String.valueOf(Math.max(1, base.getAmount())),
                    "bulk", String.valueOf(plugin.settings().bulkAmount),
                    "item", Util.itemName(base),
                    "shelf", shelf.name,
                    "currency", plugin.settings().currencySymbol)));
        }
        for (String line : plugin.promotions().loreFor(player, shelf.name, slot, basePrice)) {
            lore.add(Util.color(line));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /** Cena jednostkowa z uwzględnieniem aktualnej promocji. */
    private double unitPrice(Player player, Shelf shelf, int slot) {
        return plugin.promotions().apply(player, shelf.name, slot,
                shelf.priceFor(slot, plugin.settings().defaultPrice));
    }

    private void decorateShop(Inventory inv, Shelf shelf) {
        ItemStack filler = button(plugin.settings().fillerMaterial(), "&8 ", List.of());
        for (int i = ITEM_SLOTS; i < 54; i++) inv.setItem(i, filler);

        List<String> howTo = new ArrayList<>(List.of(
                "&7LPM: &akup &f1 szt.",
                "&7PPM: &akup &fcały stos",
                "&7Shift+LPM: &akup &f" + plugin.settings().bulkAmount + " szt."));
        if (plugin.settings().checkoutMode.equals("CHECKOUT")) {
            howTo.add("&7Aby usunąć z listy zakupów, podejdź do kasy.");
        }
        inv.setItem(49, button(Material.BOOK, "&aJak kupować?", howTo));
        inv.setItem(53, button(Material.BARRIER, "&cZamknij sklep", List.of("&7Kliknij, aby wyjść.")));
    }

    public void handleShopClick(InventoryClickEvent event, ShopHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        if (event.getClickedInventory() == null || event.getClickedInventory() != top) return;

        int slot = event.getSlot();
        if (slot == 53) {
            closeLater(player);
            return;
        }
        if (slot < 0 || slot >= ITEM_SLOTS) return;

        ItemStack base = holder.shelf.items.get(slot);
        if (base == null || base.isEmpty()) return;

        // Spam-klik jest odrzucany po cichu: bez wiadomości, dźwięku i zmiany koszyka.
        if (!plugin.clicks().allow(player.getUniqueId(), plugin.settings().guiClickCooldownMs)) return;

        if (plugin.settings().basketRequired && !plugin.baskets().canOpenShelf(player)) {
            plugin.messages().send(player, "basket-needed");
            closeLater(player);
            return;
        }

        int amount;
        if (event.isShiftClick() && event.isLeftClick()) {
            amount = plugin.settings().bulkAmount;
        } else if (event.isRightClick() && !event.isShiftClick()) {
            amount = Math.max(1, base.getAmount());
        } else if (event.isLeftClick() && !event.isShiftClick()) {
            amount = 1;
        } else {
            return;
        }
        if (plugin.settings().checkoutMode.equals("INSTANT")) {
            purchase(player, holder.shelf, slot, amount);
        } else {
            addToCart(player, holder.shelf, slot, amount);
        }
    }

    private void addToCart(Player player, Shelf shelf, int slot, int amount) {
        ItemStack base = shelf.items.get(slot);
        if (base == null || base.isEmpty()) return;
        double total = unitPrice(player, shelf, slot) * amount;
        if (!plugin.cart().add(player, base, amount, total)) {
            plugin.messages().send(player, "purchase-error");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }
        plugin.messages().send(player, "cart-added",
                "amount", String.valueOf(amount),
                "item", Util.itemName(base),
                "price", plugin.economy().format(total));
        plugin.sound(player, plugin.settings().basketSound);
    }

    private void purchase(Player player, Shelf shelf, int slot, int amount) {
        ItemStack base = shelf.items.get(slot);
        if (base == null || base.isEmpty() || amount <= 0) return;

        if (!plugin.economy().isAvailable()) {
            plugin.messages().send(player, "economy-unavailable");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        ItemStack give = base.clone();
        give.setAmount(amount);
        String name = Util.itemName(base);

        if (!canFit(player, give)) {
            plugin.messages().send(player, "no-space", "amount", String.valueOf(amount), "item", name);
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        double unit = unitPrice(player, shelf, slot);
        double total = unit * amount;

        if (plugin.economy().isBankActive()) {
            purchaseByBank(player, shelf, slot, amount, base, name, total);
            return;
        }

        if (!plugin.economy().has(player, total)) {
            plugin.messages().send(player, "no-money",
                    "price", plugin.economy().format(total),
                    "balance", plugin.economy().balanceText(player));
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }
        if (!plugin.economy().withdraw(player, total)) {
            plugin.messages().send(player, "purchase-error");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        Map<Integer, ItemStack> leftover = player.getInventory().addItem(give);
        if (!leftover.isEmpty()) {
            int notGiven = leftover.values().stream().mapToInt(ItemStack::getAmount).sum();
            int delivered = Math.max(0, amount - notGiven);
            if (delivered > 0) {
                ItemStack added = give.clone();
                added.setAmount(delivered);
                player.getInventory().removeItem(added);
            }
            plugin.economy().deposit(player, total);
            plugin.messages().send(player, "purchase-error");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        if (plugin.economy().isFree()) {
            plugin.messages().send(player, "bought-free",
                    "amount", String.valueOf(amount), "item", name, "price", plugin.economy().format(total));
        } else {
            plugin.messages().send(player, "bought",
                    "amount", String.valueOf(amount), "item", name, "price", plugin.economy().format(total));
        }
        plugin.sound(player, plugin.settings().buySound);
        plugin.cart().add(player, base, amount, total);
        handleTax(player, total);
        logPurchase(player, shelf, slot, amount, total);
        if (plugin.settings().basketRemoveAfterPurchase) {
            plugin.baskets().remove(player);
            plugin.cart().finish(player);
        }
    }

    /** Płatność kartą zawsze wymaga własnej karty w ekwipunku. */
    private boolean requireCard(Player player) {
        if (!plugin.bank().available()) {
            plugin.messages().send(player, "card-pay-disabled");
            plugin.sound(player, plugin.settings().errorSound);
            return false;
        }
        if (!plugin.settings().bankRequireCard) return true; // sam PIN wystarczy
        if (plugin.bank().hasValidCard(player)) return true;
        String key = plugin.bank().hasAnyCard(player) ? "bank-card-foreign" : "bank-card-required";
        plugin.messages().send(player, key);
        plugin.sound(player, plugin.settings().errorSound);
        return false;
    }

    /** Zakup natychmiastowy płatny przez API SkyRiseBank (asynchronicznie). */
    private void purchaseByBank(Player player, Shelf shelf, int slot, int amount,
                                ItemStack base, String name, double total) {
        UUID uuid = player.getUniqueId();
        if (!processing.add(uuid)) return;
        plugin.messages().send(player, "bank-processing");

        plugin.bank().withdraw(player, total, result -> {
            processing.remove(uuid);
            if (!player.isOnline()) {
                refundBank(player, total);
                return;
            }
            if (!result.success()) {
                bankFailure(player, result, total);
                return;
            }

            ItemStack give = base.clone();
            give.setAmount(amount);
            if (!canFit(player, give)) {
                refundBank(player, total);
                plugin.messages().send(player, "no-space", "amount", String.valueOf(amount), "item", name);
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(give);
            if (!leftover.isEmpty()) {
                int notGiven = leftover.values().stream().mapToInt(ItemStack::getAmount).sum();
                int delivered = Math.max(0, amount - notGiven);
                if (delivered > 0) {
                    ItemStack added = give.clone();
                    added.setAmount(delivered);
                    player.getInventory().removeItem(added);
                }
                refundBank(player, total);
                plugin.messages().send(player, "purchase-error");
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }

            plugin.messages().send(player, "bought",
                    "amount", String.valueOf(amount), "item", name, "price", plugin.economy().format(total));
            plugin.sound(player, plugin.settings().buySound);
            plugin.cart().add(player, base, amount, total);
            handleTax(player, total);
            logPurchase(player, shelf, slot, amount, total);
            if (plugin.settings().basketRemoveAfterPurchase) {
                plugin.baskets().remove(player);
                plugin.cart().finish(player);
            }
        });
    }

    private void refundBank(Player player, double total) {
        plugin.bank().deposit(player.getUniqueId(), total, "SkyRiseSklep - zwrot", null);
    }

    private void bankFailure(Player player, BankHook.ChargeResult result, double total) {
        String key = switch (result.status()) {
            case "INSUFFICIENT_FUNDS", "LIMIT_EXCEEDED", "INVALID_AMOUNT" -> "bank-no-money";
            case "NO_ACCOUNT" -> "bank-no-account";
            case "FROZEN" -> "bank-frozen";
            default -> "bank-error";
        };
        String balance = result.balance() > 0
                ? plugin.economy().format(result.balance())
                : plugin.bank().balanceText(player);
        plugin.messages().send(player, key,
                "price", plugin.economy().format(total), "balance", balance);
        plugin.sound(player, plugin.settings().errorSound);
    }

    private boolean canFit(Player player, ItemStack item) {
        Inventory tmp = Bukkit.createInventory(null, 36);
        ItemStack[] storage = player.getInventory().getStorageContents();
        for (int i = 0; i < Math.min(36, storage.length); i++) {
            if (storage[i] != null && !storage[i].isEmpty()) tmp.setItem(i, storage[i].clone());
        }
        return tmp.addItem(item.clone()).isEmpty();
    }

    private void logPurchase(Player player, Shelf shelf, int slot, int amount, double total) {
        if (!plugin.settings().logPurchases) return;
        try {
            File dir = new File(plugin.getDataFolder(), "logs");
            if (!dir.exists()) dir.mkdirs();
            String line = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                    + " | " + player.getName() + " | " + shelf.name + " | slot=" + (slot + 1)
                    + " | " + amount + "x " + Util.itemName(shelf.items.get(slot))
                    + " | " + plugin.economy().format(total) + System.lineSeparator();
            Files.writeString(new File(dir, "zakupy.log").toPath(), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // logowanie nie może zepsuć zakupu
        }
    }

    // ------------------------------------------------------------------ KASA

    public void openCheckout(Player player) {
        if (plugin.settings().checkoutMode.equals("INSTANT")) {
            plugin.messages().send(player, "checkout-disabled");
            return;
        }

        CheckoutHolder holder = new CheckoutHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, Util.color(plugin.settings().checkoutTitle));
        holder.setInventory(inv);

        holder.displayed().clear();
        List<CartEntry> entries = plugin.cart().entries(player);
        int slot = 0;
        for (CartEntry entry : entries) {
            if (slot >= ITEM_SLOTS) break;
            ItemStack base = DataStore.decode(entry.itemBase64());
            if (base == null || base.isEmpty()) continue;

            ItemStack display = base.clone();
            display.setAmount(Math.min(Math.max(1, entry.amount()), Math.max(1, display.getMaxStackSize())));
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
                for (String line : plugin.settings().checkoutItemLore) {
                    lore.add(Util.color(Util.replace(line,
                            "amount", String.valueOf(entry.amount()),
                            "price", plugin.economy().format(entry.price()),
                            "item", entry.item())));
                }
                for (String line : plugin.settings().checkoutRemoveLore) {
                    lore.add(Util.color(Util.replace(line,
                            "amount", String.valueOf(entry.amount()),
                            "price", plugin.economy().format(entry.price()),
                            "item", entry.item())));
                }
                meta.lore(lore);
                display.setItemMeta(meta);
            }
            holder.displayed().add(entry);
            inv.setItem(slot++, display);
        }

        decorateCheckout(inv, entries.size(), plugin.cart().total(entries));
        player.openInventory(inv);
        plugin.sound(player, plugin.settings().openSound);
    }

    private void decorateCheckout(Inventory inv, int count, double total) {
        Settings s = plugin.settings();
        ItemStack filler = button(s.fillerMaterial(), "&8 ", List.of());
        for (int i = ITEM_SLOTS; i < 54; i++) inv.setItem(i, filler);

        inv.setItem(45, button(Material.BOOK, s.checkoutInfoButton, List.of(
                "&7Pozycje: &f" + count,
                "&7Do zapłaty: &e" + plugin.economy().format(total))));
        inv.setItem(CASH_SLOT, button(material(s.checkoutCashMaterial, Material.GOLD_BLOCK),
                Util.replace(s.checkoutPayButton, "total", plugin.economy().format(total)),
                List.of()));

        if (s.checkoutCardEnabled && plugin.bank().available()) {
            inv.setItem(CARD_SLOT, button(material(s.checkoutCardMaterial, Material.LAPIS_BLOCK),
                    Util.replace(s.checkoutCardButton, "total", plugin.economy().format(total)),
                    List.of()));
        }
        inv.setItem(50, button(Material.REDSTONE, s.checkoutClearButton,
                List.of("&7Usuwa wszystko z koszyka.")));
        inv.setItem(53, button(Material.BARRIER, s.checkoutCloseButton,
                List.of("&7Zamyka podsumowanie.")));
    }

    public void handleCheckoutClick(InventoryClickEvent event, CheckoutHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        if (event.getClickedInventory() == null || event.getClickedInventory() != top) return;

        int clicked = event.getSlot();
        if (clicked == 53) {
            closeLater(player);
            return;
        }
        if (!plugin.clicks().allow(player.getUniqueId(), plugin.settings().guiClickCooldownMs)) return;
        if (clicked >= 0 && clicked < ITEM_SLOTS) {
            removeFromCheckout(player, holder, clicked, event);
            return;
        }

        switch (clicked) {
            case CARD_SLOT -> {
                if (plugin.settings().checkoutCardEnabled) payByCard(player);
            }
            case CASH_SLOT -> {
                pay(player);
                closeLater(player);
            }
            case 50 -> {
                plugin.cart().clear(player);
                plugin.messages().send(player, "cart-cleared");
                closeLater(player);
            }
            default -> {
                // pozostałe sloty są tylko podglądem
            }
        }
    }

    /** Usuwanie pojedynczej pozycji z podsumowania: LPM = 1 sztuka, PPM/Shift = cała pozycja. */
    private void removeFromCheckout(Player player, CheckoutHolder holder, int slot, InventoryClickEvent event) {
        List<CartEntry> displayed = holder.displayed();
        if (slot >= displayed.size()) return;
        CartEntry entry = displayed.get(slot);
        ItemStack shown = event.getView().getTopInventory().getItem(slot);
        if (entry == null || shown == null || shown.isEmpty()) return;

        boolean wholeLine = event.isRightClick() || event.isShiftClick();
        if (wholeLine) {
            CartEntry removed = plugin.cart().removeLine(player, entry.itemBase64());
            if (removed == null) return;
            plugin.messages().send(player, "checkout-line-removed",
                    "amount", String.valueOf(removed.amount()), "item", removed.item());
        } else {
            if (!plugin.cart().removeOne(player, entry.itemBase64())) return;
            plugin.messages().send(player, "checkout-item-removed", "item", entry.item());
        }
        plugin.sound(player, plugin.settings().basketSound);
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) openCheckout(player);
        });
    }

    private void pay(Player player) {
        if (!plugin.economy().isAvailable()) {
            plugin.messages().send(player, "economy-unavailable");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }
        List<CartEntry> entries = new ArrayList<>();
        for (CartEntry entry : plugin.cart().entries(player)) {
            if (!plugin.cart().expand(entry).isEmpty()) entries.add(entry);
        }
        if (entries.isEmpty()) {
            plugin.messages().send(player, "cart-empty");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        double total = plugin.cart().total(entries);
        if (!canFitAll(player, entries)) {
            plugin.messages().send(player, "checkout-no-space");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }
        if (plugin.economy().isBankActive()) {
            payByBank(player, entries, total);
            return;
        }
        if (!plugin.economy().has(player, total)) {
            plugin.messages().send(player, "no-money",
                    "price", plugin.economy().format(total),
                    "balance", plugin.economy().balanceText(player));
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }
        if (!plugin.economy().withdraw(player, total)) {
            plugin.messages().send(player, "purchase-error");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        List<ItemStack> delivered = new ArrayList<>();
        boolean failed = false;
        for (CartEntry entry : entries) {
            for (ItemStack stack : plugin.cart().expand(entry)) {
                if (player.getInventory().addItem(stack).isEmpty()) {
                    delivered.add(stack);
                } else {
                    failed = true;
                    break;
                }
            }
            if (failed) break;
        }
        if (failed) {
            for (ItemStack stack : delivered) player.getInventory().removeItem(stack);
            plugin.economy().deposit(player, total);
            plugin.messages().send(player, "purchase-error");
            plugin.sound(player, plugin.settings().errorSound);
            return;
        }

        handleTax(player, total);
        if (plugin.settings().checkoutClearAfterPayment) plugin.cart().finish(player);
        else plugin.cart().afterPurchase(player);
        if (plugin.settings().basketRemoveAfterPurchase) plugin.baskets().remove(player);

        plugin.messages().send(player, "checkout-paid",
                "price", plugin.economy().format(total),
                "count", String.valueOf(entries.size()),
                "method", "gotówka");
        plugin.sound(player, plugin.settings().buySound);
        logCheckout(player, entries.size(), total);
    }

    /** Zapłata za cały koszyk przez API SkyRiseBank - bez blokowania głównego wątku. */
    private void payByBank(Player player, List<CartEntry> entries, double total) {
        UUID uuid = player.getUniqueId();
        if (!processing.add(uuid)) return;
        plugin.messages().send(player, "bank-processing");

        plugin.bank().withdraw(player, total, result -> {
            processing.remove(uuid);
            if (!player.isOnline()) {
                refundBank(player, total);
                return;
            }
            if (!result.success()) {
                bankFailure(player, result, total);
                return;
            }
            if (!canFitAll(player, entries)) {
                refundBank(player, total);
                plugin.messages().send(player, "checkout-no-space");
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }

            List<ItemStack> delivered = new ArrayList<>();
            boolean failed = false;
            for (CartEntry entry : entries) {
                for (ItemStack stack : plugin.cart().expand(entry)) {
                    if (player.getInventory().addItem(stack).isEmpty()) {
                        delivered.add(stack);
                    } else {
                        failed = true;
                        break;
                    }
                }
                if (failed) break;
            }
            if (failed) {
                for (ItemStack stack : delivered) player.getInventory().removeItem(stack);
                refundBank(player, total);
                plugin.messages().send(player, "purchase-error");
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }

            handleTax(player, total);
            if (plugin.settings().checkoutClearAfterPayment) plugin.cart().finish(player);
            else plugin.cart().afterPurchase(player);
            if (plugin.settings().basketRemoveAfterPurchase) plugin.baskets().remove(player);

            plugin.messages().send(player, "checkout-paid",
                    "price", plugin.economy().format(total),
                    "count", String.valueOf(entries.size()),
                    "method", "gotówka");
            plugin.sound(player, plugin.settings().buySound);
            logCheckout(player, entries.size(), total);
        });
    }

    // --------------------------------------------------------------- KARTA + PIN

    /** Przycisk "KARTĄ": wpierw wymuszony PIN w dialogu, potem pobranie z konta karty. */
    public void payByCard(Player player) {
        Settings s = plugin.settings();
        if (!s.checkoutCardEnabled || !plugin.bank().available() || !plugin.bank().cardReady()) {
            plugin.messages().send(player, "card-pay-disabled");
            plugin.sound(player, s.errorSound);
            return;
        }

        List<CartEntry> entries = new ArrayList<>();
        for (CartEntry entry : plugin.cart().entries(player)) {
            if (!plugin.cart().expand(entry).isEmpty()) entries.add(entry);
        }
        if (entries.isEmpty()) {
            plugin.messages().send(player, "cart-empty");
            plugin.sound(player, s.errorSound);
            return;
        }
        if (!requireCard(player)) return;

        double total = plugin.cart().total(entries);
        if (!canFitAll(player, entries)) {
            plugin.messages().send(player, "checkout-no-space");
            plugin.sound(player, s.errorSound);
            return;
        }

        UUID uuid = player.getUniqueId();
        if (!processing.add(uuid)) return;

        if (s.pinEnabled) {
            plugin.pinPrompt().open(player, plugin.bank().format(total), plugin.bank().cardLabel(player),
                    () -> chargeCard(player, entries, total),
                    () -> processing.remove(uuid));
        } else {
            chargeCard(player, entries, total);
        }
    }

    private void chargeCard(Player player, List<CartEntry> entries, double total) {
        UUID uuid = player.getUniqueId();
        plugin.messages().send(player, "card-processing");

        plugin.bank().cardWithdraw(player, total, result -> {
            processing.remove(uuid);
            if (!player.isOnline()) {
                plugin.bank().cardRefund(uuid, total);
                return;
            }
            if (!result.success()) {
                cardFailure(player, result, total);
                return;
            }
            if (!canFitAll(player, entries)) {
                plugin.bank().cardRefund(uuid, total);
                plugin.messages().send(player, "checkout-no-space");
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }

            List<ItemStack> delivered = new ArrayList<>();
            boolean failed = false;
            for (CartEntry entry : entries) {
                for (ItemStack stack : plugin.cart().expand(entry)) {
                    if (player.getInventory().addItem(stack).isEmpty()) {
                        delivered.add(stack);
                    } else {
                        failed = true;
                        break;
                    }
                }
                if (failed) break;
            }
            if (failed) {
                for (ItemStack stack : delivered) player.getInventory().removeItem(stack);
                plugin.bank().cardRefund(uuid, total);
                plugin.messages().send(player, "purchase-error");
                plugin.sound(player, plugin.settings().errorSound);
                return;
            }

            handleTax(player, total);
            if (plugin.settings().checkoutClearAfterPayment) plugin.cart().finish(player);
            else plugin.cart().afterPurchase(player);
            if (plugin.settings().basketRemoveAfterPurchase) plugin.baskets().remove(player);

            plugin.messages().send(player, "checkout-paid",
                    "price", plugin.bank().format(total),
                    "count", String.valueOf(entries.size()),
                    "method", "karta");
            plugin.sound(player, plugin.settings().buySound);
            logCheckout(player, entries.size(), total);
        });
    }

    private void cardFailure(Player player, BankHook.ChargeResult result, double total) {
        String key = switch (result.status()) {
            case "INSUFFICIENT_FUNDS", "LIMIT_EXCEEDED", "INVALID_AMOUNT" -> "card-no-money";
            case "NO_ACCOUNT" -> "card-no-account";
            default -> "bank-error";
        };
        String balance = plugin.bank().format(result.balance());
        plugin.messages().send(player, key,
                "price", plugin.bank().format(total), "balance", balance);
        plugin.sound(player, plugin.settings().errorSound);
    }

    private boolean canFitAll(Player player, List<CartEntry> entries) {
        Inventory tmp = Bukkit.createInventory(null, 36);
        ItemStack[] storage = player.getInventory().getStorageContents();
        for (int i = 0; i < Math.min(36, storage.length); i++) {
            if (storage[i] != null && !storage[i].isEmpty()) tmp.setItem(i, storage[i].clone());
        }
        for (CartEntry entry : entries) {
            for (ItemStack stack : plugin.cart().expand(entry)) {
                if (!tmp.addItem(stack.clone()).isEmpty()) return false;
            }
        }
        return true;
    }

    private void logCheckout(Player player, int count, double total) {
        if (!plugin.settings().logPurchases) return;
        try {
            File dir = new File(plugin.getDataFolder(), "logs");
            if (!dir.exists()) dir.mkdirs();
            String line = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                    + " | KASA | " + player.getName() + " | pozycje=" + count
                    + " | " + plugin.economy().format(total) + System.lineSeparator();
            Files.writeString(new File(dir, "zakupy.log").toPath(), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // logowanie nie może zepsuć płatności
        }
    }

    /**
     * Podatek jest już wliczony w cenę przedmiotów - gracz dopłaca nic,
     * a 10% z zapłaconej kwoty trafia na nick z tax.receiver.
     */
    private void handleTax(Player player, double total) {
        Settings s = plugin.settings();
        if (!s.taxEnabled || s.taxRate <= 0 || s.taxReceiver == null || s.taxReceiver.isBlank()) return;
        double tax = total * s.taxRate;
        if (tax <= 0) return;
        if (!plugin.economy().transferTo(s.taxReceiver, tax)) return;
        if (s.taxLog) logTax(player, s.taxReceiver, tax);
    }

    private void logTax(Player player, String receiver, double tax) {
        try {
            File dir = new File(plugin.getDataFolder(), "logs");
            if (!dir.exists()) dir.mkdirs();
            String line = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                    + " | PODATEK | " + player.getName() + " -> " + receiver
                    + " | " + plugin.economy().format(tax) + System.lineSeparator();
            Files.writeString(new File(dir, "podatek.log").toPath(), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // log nie może zepsuć płatności
        }
    }

    // ------------------------------------------------------------------ ADMIN

    public void openEditor(Player player, Shelf shelf) {
        EditorHolder holder = new EditorHolder(shelf);
        Inventory inv = Bukkit.createInventory(holder, 54,
                Util.color(Util.replace(plugin.settings().editorTitle, "shelf", shelf.name)));
        holder.setInventory(inv);

        for (int slot = 0; slot < ITEM_SLOTS; slot++) {
            ItemStack item = shelf.items.get(slot);
            if (item != null && !item.isEmpty()) inv.setItem(slot, item.clone());
        }
        decorateEditor(inv, shelf);
        player.openInventory(inv);
        plugin.sound(player, plugin.settings().openSound);
    }

    private void decorateEditor(Inventory inv, Shelf shelf) {
        ItemStack filler = button(plugin.settings().fillerMaterial(), "&8 ", List.of());
        for (int i = ITEM_SLOTS; i < 54; i++) inv.setItem(i, filler);

        List<String> info = new ArrayList<>(plugin.settings().editorInfo);
        info.add("&7Cena domyślna: &e" + plugin.economy().format(shelf.priceFor(-1, plugin.settings().defaultPrice)));
        info.add("&7Przedmiotów: &f" + shelf.items.size() + " &7| Punktów: &f" + shelf.targets.size());

        inv.setItem(45, button(Material.BOOK, "&aEdytor: &f" + shelf.name, info));
        inv.setItem(49, button(Material.EMERALD, "&aZapisz i zamknij", List.of("&7Zapisuje 45 górnych slotów.")));
        inv.setItem(50, button(Material.GOLD_INGOT, "&eUstaw cenę domyślną", List.of("&7Wpisz kwotę na czacie.")));
        inv.setItem(51, button(Material.REDSTONE, "&cWyczyść ceny", List.of("&7Wszystkie sloty wracają do ceny domyślnej.")));
        inv.setItem(53, button(Material.BARRIER, "&cAnuluj zmiany", List.of("&7Zamyka bez zapisywania.")));
    }

    public void handleEditorClick(InventoryClickEvent event, EditorHolder holder) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        int raw = event.getRawSlot();

        if (raw >= ITEM_SLOTS && raw < 54) {
            event.setCancelled(true);
            if (raw != 53 && !plugin.clicks().allow(player.getUniqueId(),
                    plugin.settings().guiClickCooldownMs)) return;
            switch (raw) {
                case 49 -> {
                    saveEditor(top, holder.shelf);
                    closeLater(player);
                    plugin.messages().send(player, "editor-saved", "shelf", holder.shelf.name);
                }
                case 50 -> {
                    saveEditor(top, holder.shelf);
                    plugin.listeners().startChat(player, Listeners.ChatType.DEFAULT_PRICE, holder.shelf.name, -1);
                    closeLater(player);
                    plugin.messages().send(player, "price-default-prompt", "shelf", holder.shelf.name);
                }
                case 51 -> {
                    saveEditor(top, holder.shelf);
                    holder.shelf.prices.clear();
                    plugin.data().save();
                    plugin.messages().send(player, "editor-prices-cleared", "shelf", holder.shelf.name);
                }
                case 53 -> {
                    holder.cancelled = true;
                    closeLater(player);
                    plugin.messages().send(player, "editor-cancelled");
                }
                default -> {
                    // puste przyciski / wypełniacze
                }
            }
            return;
        }

        // Shift + PPM na przedmiocie -> ustawienie ceny przez czat
        if (raw >= 0 && raw < ITEM_SLOTS && event.getClickedInventory() == top
                && event.getClick() == ClickType.SHIFT_RIGHT) {
            event.setCancelled(true);
            ItemStack current = top.getItem(raw);
            if (current == null || current.isEmpty()) return;
            if (!plugin.clicks().allow(player.getUniqueId(), plugin.settings().guiClickCooldownMs)) return;
            saveEditor(top, holder.shelf);
            plugin.listeners().startChat(player, Listeners.ChatType.PRICE, holder.shelf.name, raw);
            closeLater(player);
            plugin.messages().send(player, "price-prompt",
                    "slot", String.valueOf(raw + 1), "shelf", holder.shelf.name);
        }
        // zwykłe kliknięcia w slotach 0-44 oraz w ekwipunku gracza są dozwolone
    }

    public void saveEditor(Inventory inv, Shelf shelf) {
        Map<Integer, ItemStack> fresh = new HashMap<>();
        for (int slot = 0; slot < ITEM_SLOTS; slot++) {
            ItemStack item = inv.getItem(slot);
            if (item != null && !item.isEmpty()) fresh.put(slot, item.clone());
        }
        shelf.items.clear();
        shelf.items.putAll(fresh);
        shelf.prices.keySet().removeIf(slot -> !shelf.items.containsKey(slot));
        plugin.data().save();
    }

    public void handleDrag(InventoryDragEvent event, boolean editor) {
        if (!editor) {
            event.setCancelled(true);
            return;
        }
        for (int slot : event.getRawSlots()) {
            if (slot >= ITEM_SLOTS && slot < 54) {
                event.setCancelled(true);
                return;
            }
        }
    }

    private void closeLater(Player player) {
        Bukkit.getScheduler().runTask(plugin, () -> player.closeInventory());
    }

    private Material material(String name, Material fallback) {
        Material m = name == null ? null : Material.matchMaterial(name);
        return m == null || m.isAir() ? fallback : m;
    }

    private ItemStack button(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Util.color(name));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) lines.add(Util.color(line));
        meta.lore(lines);
        item.setItemMeta(meta);
        return item;
    }

    // ------------------------------------------------------------------ HOLDERY

    public static final class ShopHolder implements InventoryHolder {
        public final Shelf shelf;
        private Inventory inventory;

        public ShopHolder(Shelf shelf) {
            this.shelf = shelf;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    public static final class EditorHolder implements InventoryHolder {
        public final Shelf shelf;
        public boolean cancelled = false;
        private Inventory inventory;

        public EditorHolder(Shelf shelf) {
            this.shelf = shelf;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    public static final class CheckoutHolder implements InventoryHolder {
        private Inventory inventory;
        /** Pozycje koszyka w kolejności slotów 0-44 podsumowania. */
        private final List<CartEntry> displayed = new ArrayList<>();

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public List<CartEntry> displayed() {
            return displayed;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
