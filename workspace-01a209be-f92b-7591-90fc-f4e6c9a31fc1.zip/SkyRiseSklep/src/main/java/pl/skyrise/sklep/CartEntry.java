package pl.skyrise.sklep;

/**
 * Jedna pozycja w koszyku gracza.
 * itemBase64 to pełny ItemStack (ilość 1) zapisany przez ItemStack.serializeAsBytes(),
 * dzięki czemu kasa może wydać dokładnie ten sam przedmiot (również z Nexo).
 */
public record CartEntry(String item, int amount, double price, String itemBase64) {
}
