package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.SoundCategory;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/** SkyRiseSklep - uniwersalny sklep z koszykiem i regałami (Purpur 1.21.10). */
public final class SkyRiseSklep extends JavaPlugin {

    /** Znacznik PDC dodawany do każdego wydanego koszyka. */
    public static final NamespacedKey BASKET_KEY = new NamespacedKey("skyrise", "basket");
    /** UUID właściciela koszyka - nikt inny nie może go podnieść. */
    public static final NamespacedKey BASKET_OWNER_KEY = new NamespacedKey("skyrise", "basket_owner");

    private Settings settings;
    private Messages messages;
    private DataStore data;
    private NexoHook nexo;
    private EconomyHook economy;
    private BankHook bank;
    private PinPrompt pinPrompt;
    private TabHook tab;
    private CartManager cart;
    private BasketManager baskets;
    private GuiManager gui;
    private AdminPanel adminPanel;
    private PromotionManager promotions;
    private Listeners listeners;
    private BasketGuard guard;
    private Commands commands;
    private BukkitTask basketWatcher;
    private final ClickGuard clicks = new ClickGuard();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        // Dokłada wartości z config.yml w jarze jako defaults - stare pliki nie mają nowych kluczy.
        reloadConfig();

        settings = new Settings(this);
        messages = new Messages(this);
        data = new DataStore(this);
        data.load();

        nexo = new NexoHook(this);
        nexo.init();

        bank = new BankHook(this);
        bank.init();
        pinPrompt = new PinPrompt(this);
        economy = new EconomyHook(this, settings, bank);
        economy.setup();

        // SkyRiseBank może zarejestrować API chwilę po starcie - spróbuj jeszcze raz.
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!bank.available() || !bank.cardReady()) {
                bank.init();
                economy.setup();
            }
        }, 20L);

        tab = new TabHook(this);
        tab.init();
        cart = new CartManager(this);

        baskets = new BasketManager(this);
        gui = new GuiManager(this);
        promotions = new PromotionManager(this);
        promotions.reload();
        adminPanel = new AdminPanel(this);
        listeners = new Listeners(this);
        guard = new BasketGuard(this);
        getServer().getPluginManager().registerEvents(listeners, this);
        getServer().getPluginManager().registerEvents(guard, this);
        getServer().getPluginManager().registerEvents(adminPanel, this);

        commands = new Commands(this);
        PluginCommand command = getCommand("skyrise");
        if (command != null) {
            command.setExecutor(commands);
            command.setTabCompleter(commands);
        } else {
            getLogger().warning("Nie znaleziono komendy 'skyrise' w plugin.yml!");
        }

        restartBasketWatcher();
        promotions.start();

        getLogger().info("SkyRiseSklep 1.0.0 uruchomiony (1.21.10).");
        getLogger().info("Nexo: " + (nexo.available() ? "TAK" : "NIE") + " | Ekonomia: " + economy.status()
                + " | " + tab.status()
                + " | Regały: " + data.all().size() + " | Punkty koszyka: " + data.basketPoints().size());
        getLogger().info("Konfiguracja: /srs help");
    }

    @Override
    public void onDisable() {
        if (promotions != null) promotions.stop();
        if (basketWatcher != null) {
            basketWatcher.cancel();
            basketWatcher = null;
        }
        if (pinPrompt != null) pinPrompt.cancelAll();
        if (cart != null) {
            for (Player player : Bukkit.getOnlinePlayers()) cart.hide(player);
        }
        if (data != null) data.save();
        getLogger().info("SkyRiseSklep wyłączony.");
    }

    /** Cykliczne sprawdzanie odległości od sklepu (basket.auto-remove-distance). */
    private void restartBasketWatcher() {
        if (basketWatcher != null) {
            basketWatcher.cancel();
            basketWatcher = null;
        }
        long period = 20L * settings.basketAutoRemoveCheckSeconds;
        basketWatcher = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (settings.basketAutoRemoveDistance <= 0) return;
            for (Player player : Bukkit.getOnlinePlayers()) baskets.checkDistance(player);
        }, period, period);
    }

    public void reloadAll() {
        if (pinPrompt != null) pinPrompt.cancelAll();
        reloadConfig();
        settings.load();
        messages.reload();
        data.load();
        nexo.init();
        tab.init();
        bank.init();
        economy.setup();
        promotions.reload();
        promotions.start();
        clicks.clear();
        for (Player player : Bukkit.getOnlinePlayers()) cart.applyDefault(player);
        restartBasketWatcher();
    }

    public void sound(Player player, String name) {
        if (name == null || name.isBlank()) return;
        String key = name.contains(":") ? name : "minecraft:" + name;
        try {
            player.playSound(player.getLocation(), key, SoundCategory.MASTER, 1.0f, 1.0f);
        } catch (Throwable ignored) {
            // nieznany dźwięk nie może przerwać działania pluginu
        }
    }

    public Settings settings() {
        return settings;
    }

    public Messages messages() {
        return messages;
    }

    public DataStore data() {
        return data;
    }

    public NexoHook nexo() {
        return nexo;
    }

    public EconomyHook economy() {
        return economy;
    }

    public BankHook bank() {
        return bank;
    }

    public PinPrompt pinPrompt() {
        return pinPrompt;
    }

    public BasketManager baskets() {
        return baskets;
    }

    public GuiManager gui() {
        return gui;
    }

    public AdminPanel adminPanel() {
        return adminPanel;
    }

    public PromotionManager promotions() {
        return promotions;
    }

    public ClickGuard clicks() {
        return clicks;
    }

    public Listeners listeners() {
        return listeners;
    }

    public TabHook tab() {
        return tab;
    }

    public CartManager cart() {
        return cart;
    }
}
