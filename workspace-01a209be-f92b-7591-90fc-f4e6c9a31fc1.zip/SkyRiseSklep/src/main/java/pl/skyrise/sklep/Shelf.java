package pl.skyrise.sklep;

import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Jeden regał / jedna sekcja sklepu. */
public final class Shelf {

    public final String name;
    /** Klucze: block|swiat|x|y|z  albo  entity|uuid */
    public final Set<String> targets = new LinkedHashSet<>();
    /** Slot (0-44) -> przedmiot na sprzedaż */
    public final Map<Integer, ItemStack> items = new HashMap<>();
    /** Slot (0-44) -> cena za 1 sztukę */
    public final Map<Integer, Double> prices = new HashMap<>();
    /** null = użyj ceny domyślnej z configu */
    public Double defaultPrice;

    public Shelf(String name) {
        this.name = name;
    }

    public double priceFor(int slot, double globalDefault) {
        Double p = prices.get(slot);
        if (p != null) return p;
        if (defaultPrice != null) return defaultPrice;
        return globalDefault;
    }
}
