package pl.skyrise.sklep;

import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Miękka integracja z Nexo przez refleksję - plugin działa również bez Nexo.
 * Obsługuje API: com.nexomc.nexo.api.NexoItems.itemFromId(id).build()
 * oraz starsze nazwy klas (dev.nexteam...).
 */
public final class NexoHook {

    private static final String[] CANDIDATES = {
            "com.nexomc.nexo.api.NexoItems",
            "com.nexomc.nexo.NexoItems",
            "dev.nexteam.nexo.api.NexoItems"
    };

    private final SkyRiseSklep plugin;
    private Class<?> api;
    private boolean warned;

    public NexoHook(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    public void init() {
        for (String name : CANDIDATES) {
            try {
                api = Class.forName(name);
                plugin.getLogger().info("Wykryto Nexo API: " + name);
                return;
            } catch (ClassNotFoundException ignored) {
                // spróbuj kolejnej nazwy
            }
        }
        plugin.getLogger().info("Nexo nie wykryto - koszyk użyje itemu zapisanego w data.yml lub fallbacku z configu.");
    }

    public boolean available() {
        return api != null;
    }

    public ItemStack itemFromId(String id) {
        if (api == null || id == null || id.isBlank()) return null;
        for (String methodName : new String[]{"itemFromId", "getItemFromId"}) {
            try {
                Method m = api.getMethod(methodName, String.class);
                Object receiver = Modifier.isStatic(m.getModifiers()) ? null : instance();
                Object builder = m.invoke(receiver, id);
                if (builder == null) return null;
                Method build = builder.getClass().getMethod("build");
                Object result = build.invoke(builder);
                if (result instanceof ItemStack stack) return stack;
            } catch (NoSuchMethodException ignored) {
                // spróbuj kolejnej nazwy metody
            } catch (Throwable t) {
                warnOnce(t);
            }
        }
        return null;
    }

    public String idFromItem(ItemStack item) {
        if (api == null || item == null || item.isEmpty()) return null;
        for (String methodName : new String[]{"idFromItem", "getIdFromItem"}) {
            try {
                Method m = api.getMethod(methodName, ItemStack.class);
                Object receiver = Modifier.isStatic(m.getModifiers()) ? null : instance();
                Object result = m.invoke(receiver, item);
                if (result instanceof String s) return s;
            } catch (NoSuchMethodException ignored) {
                // spróbuj kolejnej nazwy metody
            } catch (Throwable ignored) {
                return null;
            }
        }
        return null;
    }

    private Object instance() {
        try {
            Field f = api.getField("INSTANCE");
            return f.get(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private void warnOnce(Throwable t) {
        if (warned) return;
        warned = true;
        plugin.getLogger().warning("Nie udało się pobrać itemu z Nexo: " + t.getClass().getSimpleName()
                + " - używam zapisanego itemu / fallbacku. Upewnij się, że ID w configu jest poprawne.");
    }
}
