package pl.skyrise.sklep;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;

/** Wiadomości z sekcji messages w config.yml. Prefix ma gradient i znak ». */
public final class Messages {

    private final SkyRiseSklep plugin;

    private String text = "Sklep";
    private String from = "#3DFF72";
    private String to = "#FFFFFF";
    private String arrow = " &8» &7";
    private boolean bold = true;

    public Messages(SkyRiseSklep plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        text = plugin.getConfig().getString("messages.prefix.text", text);
        from = plugin.getConfig().getString("messages.prefix.from", from);
        to = plugin.getConfig().getString("messages.prefix.to", to);
        arrow = plugin.getConfig().getString("messages.prefix.arrow", arrow);
        bold = plugin.getConfig().getBoolean("messages.prefix.bold", bold);
    }

    /**
     * Stare config.yml nie mają nowych kluczy - bierzemy je z configu w jarze.
     * Dzięki temu na czacie nigdy nie pojawia się nazwa klucza ani "[brak wiadomości]".
     */
    private String lookup(String path) {
        FileConfiguration cfg = plugin.getConfig();
        String value = cfg.getString(path);
        if (value == null) {
            Configuration defaults = cfg.getDefaults();
            if (defaults != null) value = defaults.getString(path);
        }
        return value;
    }

    private List<String> lookupList(String path) {
        FileConfiguration cfg = plugin.getConfig();
        List<String> value = cfg.getStringList(path);
        if (value == null || value.isEmpty()) {
            Configuration defaults = cfg.getDefaults();
            if (defaults != null) value = defaults.getStringList(path);
        }
        return value;
    }

    public String raw(String key) {
        String path = "messages." + key;
        String value = lookup(path);
        if (value == null || value.isEmpty()) {
            plugin.getLogger().warning("Brak treści wiadomości w config.yml: " + path);
            return "&cBrak komunikatu w konfiguracji.";
        }
        return value;
    }

    public List<String> rawList(String key) {
        String path = "messages." + key;
        List<String> value = lookupList(path);
        if (value == null || value.isEmpty()) {
            plugin.getLogger().warning("Brak listy wiadomości w config.yml: " + path);
            return new ArrayList<>(List.of("&7Brak opisu w konfiguracji."));
        }
        return new ArrayList<>(value);
    }

    private Component prefix() {
        Component name = Util.gradient(text, from, to);
        Component tail = Util.color(arrow);
        if (bold) name = name.decoration(TextDecoration.BOLD, true);
        // Znaczek po prefixie zawsze zostaje cienki, nie dziedziczy pogrubienia.
        tail = tail.decoration(TextDecoration.BOLD, false);
        return Component.text().append(name).append(tail).build();
    }

    /** Wyślij dowolny tekst z prefiksem: PREFIX » Tekst */
    public void line(CommandSender sender, String text, String... kv) {
        sender.sendMessage(prefix().append(Util.color(Util.replace(text, kv))));
    }

    /** Wyślij wiadomość z configu (może mieć kilka linii rozdzielonych \n). */
    public void send(CommandSender sender, String key, String... kv) {
        for (String l : raw(key).split("\\n", -1)) {
            line(sender, l, kv);
        }
    }

    /** Wyślij listę linii z configu. */
    public void lines(CommandSender sender, String key, String... kv) {
        for (String l : rawList(key)) {
            line(sender, l, kv);
        }
    }

    /** Komunikat dla wszystkich graczy online (np. start promocji). */
    public void broadcast(String key, String... kv) {
        for (Player player : Bukkit.getOnlinePlayers()) send(player, key, kv);
    }

    /** Pojedyncza linia oddzielająca opis komend. */
    public void separator(CommandSender sender) {
        line(sender, raw("help-separator"));
    }
}
