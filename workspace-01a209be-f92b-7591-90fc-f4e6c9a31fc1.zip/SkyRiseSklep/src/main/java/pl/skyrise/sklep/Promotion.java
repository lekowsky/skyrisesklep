package pl.skyrise.sklep;

/** Jedna promocja: rabat na konkretny slot regału, z czasem wygaśnięcia. */
public record Promotion(String shelf, int slot, int percent, long expiresAt, boolean automatic) {

    public String key() {
        return shelf + "|" + slot;
    }

    public boolean expired(long now) {
        return expiresAt > 0 && expiresAt <= now;
    }
}
