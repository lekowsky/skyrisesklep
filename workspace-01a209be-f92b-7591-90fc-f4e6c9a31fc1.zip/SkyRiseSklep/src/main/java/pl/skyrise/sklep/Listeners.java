package pl.skyrise.sklep;

import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Interakcje z blokami/meblami, GUI oraz czat (ustawianie cen). */
public final class Listeners implements Listener {

    public enum SelectionType {
        BASKET_ADD, BASKET_REMOVE, CHECKOUT_ADD, CHECKOUT_REMOVE,
        SHELF_CREATE, SHELF_ADD, SHELF_REMOVE
    }

    public enum ChatType {
        PRICE, DEFAULT_PRICE, SHELF_NAME
    }

    public record PendingSelection(SelectionType type, String shelf, long expires) {
    }

    public record ChatPrompt(ChatType type, String shelf, int slot, long expires) {
    }

    private record ClickRecord(String key, long time) {
    }

    private final SkyRiseSklep plugin;
    private final Map<UUID, PendingSelection> selections = new ConcurrentHashMap<>();
    private final Map<UUID, ChatPrompt> chatPrompts = new ConcurrentHashMap<>();
    private final Map<UUID, ClickRecord> recentClicks = new ConcurrentHashMap<>();

    public Listeners(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------- WYBÓR PUNKTU

    public void select(Player player, SelectionType type, String shelf, String messageKey) {
        long expires = System.currentTimeMillis() + plugin.settings().selectionTimeoutMs;
        selections.put(player.getUniqueId(), new PendingSelection(type, shelf, expires));
        plugin.messages().send(player, messageKey, "shelf", shelf == null ? "" : shelf);
    }

    public void startChat(Player player, ChatType type, String shelf, int slot) {
        long expires = System.currentTimeMillis() + plugin.settings().selectionTimeoutMs;
        chatPrompts.put(player.getUniqueId(), new ChatPrompt(type, shelf, slot, expires));
    }

    public boolean cancel(Player player) {
        UUID uuid = player.getUniqueId();
        return selections.remove(uuid) != null | chatPrompts.remove(uuid) != null;
    }

    public boolean hasSelection(Player player) {
        return player != null && selections.containsKey(player.getUniqueId());
    }

    public void clear(Player player) {
        UUID uuid = player.getUniqueId();
        selections.remove(uuid);
        chatPrompts.remove(uuid);
        recentClicks.remove(uuid);
    }

    // ------------------------------------------------------------- INTERAKCJE

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onBlockInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        Player player = event.getPlayer();
        String key = Targets.block(block);
        if (isDuplicate(player.getUniqueId(), key)) return;
        handleTarget(player, key, event, true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        Entity entity = event.getRightClicked();
        if (entity == null) return;
        String key = Targets.entity(entity);
        if (isDuplicate(player.getUniqueId(), key)) return;
        handleTarget(player, key, event, false);
    }

    private boolean isDuplicate(UUID uuid, String key) {
        long now = System.currentTimeMillis();
        ClickRecord last = recentClicks.get(uuid);
        if (last != null && last.key().equals(key) && now - last.time() < 150L) return true;
        recentClicks.put(uuid, new ClickRecord(key, now));
        return false;
    }

    private void handleTarget(Player player, String key, Cancellable event, boolean blockClick) {
        UUID uuid = player.getUniqueId();
        PendingSelection selection = selections.get(uuid);
        if (selection != null) {
            if (System.currentTimeMillis() > selection.expires()) {
                selections.remove(uuid);
                plugin.messages().send(player, "selection-expired");
                return;
            }
            selections.remove(uuid);
            event.setCancelled(true);
            applySelection(player, selection, key);
            return;
        }

        if (!player.hasPermission("skyrise.use")) {
            plugin.messages().send(player, "no-permission", "permission", "skyrise.use");
            return;
        }

        if (plugin.data().basketPoints().contains(key)) {
            event.setCancelled(true);
            if (plugin.settings().basketReturnOnReclick && plugin.baskets().hasBasket(player)) {
                plugin.baskets().returnBasket(player);
            } else if (plugin.baskets().hasBasket(player)) {
                plugin.messages().send(player, "basket-return-disabled");
            } else {
                plugin.baskets().give(player);
            }
            return;
        }

        if (plugin.data().checkoutPoints().contains(key)) {
            event.setCancelled(true);
            if (plugin.settings().checkoutRequireBasket && !plugin.baskets().canOpenShelf(player)) {
                plugin.messages().send(player, "checkout-need-basket");
                return;
            }
            plugin.gui().openCheckout(player);
            return;
        }

        Shelf shelf = plugin.data().findShelfByTarget(key);
        if (shelf == null && blockClick) {
            shelf = plugin.data().findShelfNear(key, plugin.settings().shelfRadius);
        }
        if (shelf != null) {
            event.setCancelled(true);
            if (!plugin.baskets().canOpenShelf(player)) {
                plugin.messages().send(player, "basket-needed");
                return;
            }
            plugin.gui().openShop(player, shelf);
        }
    }

    private void applySelection(Player player, PendingSelection selection, String key) {
        DataStore data = plugin.data();
        String shelfName = selection.shelf();
        String shown = Targets.describe(key);

        switch (selection.type()) {
            case BASKET_ADD -> {
                if (data.basketPoints().add(key)) {
                    data.save();
                    plugin.messages().send(player, "selection-set", "target", shown);
                } else {
                    plugin.messages().send(player, "selection-duplicate");
                }
            }
            case BASKET_REMOVE -> {
                if (data.basketPoints().remove(key)) {
                    data.save();
                    plugin.messages().send(player, "selection-removed", "target", shown);
                } else {
                    plugin.messages().send(player, "selection-not-found");
                }
            }
            case CHECKOUT_ADD -> {
                if (data.checkoutPoints().add(key)) {
                    data.save();
                    plugin.messages().send(player, "selection-set", "target", shown);
                } else {
                    plugin.messages().send(player, "selection-duplicate");
                }
            }
            case CHECKOUT_REMOVE -> {
                if (data.checkoutPoints().remove(key)) {
                    data.save();
                    plugin.messages().send(player, "selection-removed", "target", shown);
                } else {
                    plugin.messages().send(player, "selection-not-found");
                }
            }
            case SHELF_CREATE -> {
                Shelf existing = data.getShelf(shelfName);
                if (existing != null) {
                    plugin.messages().send(player, "shelf-exists", "shelf", shelfName);
                    return;
                }
                Shelf shelf = new Shelf(shelfName);
                shelf.targets.add(key);
                data.addShelf(shelf);
                data.save();
                plugin.messages().send(player, "shelf-created", "shelf", shelf.name);
                plugin.gui().openEditor(player, shelf);
            }
            case SHELF_ADD -> {
                Shelf shelf = data.getShelf(shelfName);
                if (shelf == null) {
                    plugin.messages().send(player, "shelf-missing", "shelf", shelfName);
                    return;
                }
                if (shelf.targets.add(key)) {
                    data.save();
                    plugin.messages().send(player, "shelf-target-added", "shelf", shelf.name, "target", shown);
                } else {
                    plugin.messages().send(player, "shelf-target-duplicate", "shelf", shelf.name);
                }
            }
            case SHELF_REMOVE -> {
                Shelf shelf = data.getShelf(shelfName);
                if (shelf == null) {
                    plugin.messages().send(player, "shelf-missing", "shelf", shelfName);
                    return;
                }
                if (shelf.targets.remove(key)) {
                    data.save();
                    plugin.messages().send(player, "shelf-target-removed", "shelf", shelf.name, "target", shown);
                    if (shelf.targets.isEmpty()) {
                        plugin.messages().send(player, "shelf-no-targets", "shelf", shelf.name);
                    }
                } else {
                    plugin.messages().send(player, "shelf-target-not-found", "shelf", shelf.name);
                }
            }
        }
    }

    // ------------------------------------------------------------- GUI

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof GuiManager.ShopHolder shop) {
            plugin.gui().handleShopClick(event, shop);
        } else if (holder instanceof GuiManager.EditorHolder editor) {
            plugin.gui().handleEditorClick(event, editor);
        } else if (holder instanceof GuiManager.CheckoutHolder checkout) {
            plugin.gui().handleCheckoutClick(event, checkout);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onInventoryDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof GuiManager.ShopHolder || holder instanceof GuiManager.CheckoutHolder) {
            plugin.gui().handleDrag(event, false);
        } else if (holder instanceof GuiManager.EditorHolder) {
            plugin.gui().handleDrag(event, true);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof GuiManager.EditorHolder editor && !editor.cancelled) {
            plugin.gui().saveEditor(event.getInventory(), editor.shelf);
        }
    }

    // ------------------------------------------------------------- CZAT (CENY)

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onLegacyChat(AsyncPlayerChatEvent event) {
        handleChat(event.getPlayer(), event.getMessage(), event);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onPaperChat(AsyncChatEvent event) {
        handleChat(event.getPlayer(), Util.plain(event.message()), event);
    }

    private void handleChat(Player player, String message, Cancellable event) {
        ChatPrompt prompt = chatPrompts.remove(player.getUniqueId());
        if (prompt == null) return;

        event.setCancelled(true);
        try {
            if (event instanceof AsyncPlayerChatEvent legacy) legacy.getRecipients().clear();
            if (event instanceof AsyncChatEvent paper) paper.viewers().clear();
        } catch (Throwable ignored) {
            // niektóre buildy Paper zwracają niemodyfikowalny zbiór odbiorców
        }

        if (System.currentTimeMillis() > prompt.expires()) {
            Bukkit.getScheduler().runTask(plugin, () -> plugin.messages().send(player, "selection-expired"));
            return;
        }

        String text = message.trim();
        if (text.equalsIgnoreCase("anuluj") || text.equalsIgnoreCase("cancel")) {
            String key = prompt.type() == ChatType.SHELF_NAME ? "selection-cancelled" : "price-cancelled";
            Bukkit.getScheduler().runTask(plugin, () -> plugin.messages().send(player, key));
            return;
        }

        if (prompt.type() == ChatType.SHELF_NAME) {
            String name = text;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!Commands.validShelfName(name)) {
                    plugin.messages().send(player, "shelf-invalid-name");
                    return;
                }
                if (plugin.data().getShelf(name) != null) {
                    plugin.messages().send(player, "shelf-exists", "shelf", name);
                    return;
                }
                select(player, SelectionType.SHELF_CREATE, name, "selection-shelf-create");
            });
            return;
        }

        Double value = Util.parseNumber(text);
        if (value == null || value < 0) {
            Bukkit.getScheduler().runTask(plugin, () -> plugin.messages().send(player, "price-invalid"));
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            Shelf shelf = plugin.data().getShelf(prompt.shelf());
            if (shelf == null) {
                plugin.messages().send(player, "shelf-missing", "shelf", prompt.shelf());
                return;
            }
            if (prompt.type() == ChatType.PRICE) {
                int slot = prompt.slot();
                if (slot < 0 || slot >= GuiManager.ITEM_SLOTS) return;
                shelf.prices.put(slot, value);
                plugin.data().save();
                plugin.messages().send(player, "price-set",
                        "shelf", shelf.name,
                        "slot", String.valueOf(slot + 1),
                        "price", plugin.economy().format(value));
            } else {
                shelf.defaultPrice = value;
                plugin.data().save();
                plugin.messages().send(player, "price-default-set",
                        "shelf", shelf.name, "price", plugin.economy().format(value));
            }
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // TAB tworzy gracza asynchronicznie - ustaw stan scoreboardu z opóźnieniem
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            plugin.cart().applyDefault(player);
            plugin.baskets().checkDistance(player);
        }, 40L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        plugin.baskets().checkDistance(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        clear(event.getPlayer());
        plugin.pinPrompt().cancel(event.getPlayer());
        plugin.cart().hide(event.getPlayer());
    }
}
