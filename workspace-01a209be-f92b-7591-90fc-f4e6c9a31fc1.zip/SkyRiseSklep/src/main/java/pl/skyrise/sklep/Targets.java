package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;

import java.util.UUID;

/** Jednolity format punktów: blok albo encja (mebel Nexo / Interaction). */
public final class Targets {

    private Targets() {
    }

    public static String block(Block b) {
        Location l = b.getLocation();
        return "block|" + l.getWorld().getName() + "|" + l.getBlockX() + "|" + l.getBlockY() + "|" + l.getBlockZ();
    }

    public static String entity(Entity e) {
        return "entity|" + e.getUniqueId();
    }

    /** Środek bloku albo pozycja encji - do liczenia odległości od punktu. */
    public static Location locationOf(String key) {
        if (key == null) return null;
        if (key.startsWith("block|")) {
            String[] p = key.split("\\|", 6);
            if (p.length != 5) return null;
            World world = Bukkit.getWorld(p[1]);
            if (world == null) return null;
            try {
                return new Location(world,
                        Double.parseDouble(p[2]) + 0.5,
                        Double.parseDouble(p[3]) + 0.5,
                        Double.parseDouble(p[4]) + 0.5);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        if (key.startsWith("entity|")) {
            try {
                Entity entity = Bukkit.getEntity(UUID.fromString(key.substring(7)));
                return entity == null ? null : entity.getLocation();
            } catch (IllegalArgumentException e) {
                return null;
            }
        }
        return null;
    }

    /** Odległość „po blokach" - 1 oznacza sześcian 3x3x3 wokół punktu. */
    public static int blockDistance(Location a, Location b) {
        return Math.max(
                Math.abs(a.getBlockX() - b.getBlockX()),
                Math.max(Math.abs(a.getBlockY() - b.getBlockY()),
                        Math.abs(a.getBlockZ() - b.getBlockZ())));
    }

    public static String describe(String key) {
        if (key == null) return "-";
        if (key.startsWith("block|")) {
            String[] p = key.split("\\|", 6);
            if (p.length == 5) return "blok " + p[1] + " [" + p[2] + ", " + p[3] + ", " + p[4] + "]";
            return key;
        }
        if (key.startsWith("entity|")) {
            String uuid = key.substring(7);
            return "mebel/entity " + (uuid.length() > 8 ? uuid.substring(0, 8) : uuid);
        }
        return key;
    }
}
