package pl.skyrise.sklep;

import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Tworzenie, rozpoznawanie i wydawanie koszyka (model Nexo). */
public final class BasketManager {

    private final SkyRiseSklep plugin;

    public BasketManager(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    public ItemStack create(Player owner) {
        ItemStack raw = DataStore.decode(plugin.data().basketItemBase64());
        if (raw == null || raw.isEmpty()) {
            raw = plugin.nexo().itemFromId(plugin.settings().basketNexoId);
        }
        if (raw == null || raw.isEmpty()) {
            raw = createFallback();
        }
        if (raw == null || raw.isEmpty()) return null;

        ItemStack item = raw.clone();
        item.setAmount(1);
        stripLore(item);
        mark(item, owner);
        return item;
    }

    /** Koszyk zawsze jest bez lore - niezależnie od tego, skąd pochodzi item. */
    private void stripLore(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.setLore(null);
        item.setItemMeta(meta);
    }

    private ItemStack createFallback() {
        Material material = Material.matchMaterial(plugin.settings().basketFallbackMaterial);
        if (material == null || material.isAir()) material = Material.HOPPER;

        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(Util.color(plugin.settings().basketName));

        if (plugin.settings().basketFallbackCmd > 0) {
            meta.setCustomModelData(plugin.settings().basketFallbackCmd);
        }
        String model = plugin.settings().basketFallbackItemModel;
        if (model != null && !model.isBlank()) {
            NamespacedKey key = NamespacedKey.fromString(model);
            if (key != null) meta.setItemModel(key);
        }
        item.setItemMeta(meta);
        return item;
    }

    private void mark(ItemStack item, Player owner) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.getPersistentDataContainer().set(SkyRiseSklep.BASKET_KEY, PersistentDataType.BYTE, (byte) 1);
        if (owner != null) {
            meta.getPersistentDataContainer().set(SkyRiseSklep.BASKET_OWNER_KEY,
                    PersistentDataType.STRING, owner.getUniqueId().toString());
        }
        item.setItemMeta(meta);
    }

    private ItemStack stripMarker(ItemStack item) {
        if (item == null || item.isEmpty()) return item;
        ItemStack copy = item.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta == null) return copy;
        meta.getPersistentDataContainer().remove(SkyRiseSklep.BASKET_KEY);
        copy.setItemMeta(meta);
        return copy;
    }

    public boolean isBasket(ItemStack item) {
        if (item == null || item.isEmpty()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;

        if (meta.getPersistentDataContainer().has(SkyRiseSklep.BASKET_KEY, PersistentDataType.BYTE)) return true;

        String configuredId = plugin.settings().basketNexoId;
        if (configuredId != null && !configuredId.isBlank()) {
            String id = plugin.nexo().idFromItem(item);
            if (id != null && id.equalsIgnoreCase(configuredId)) return true;
        }

        ItemStack saved = DataStore.decode(plugin.data().basketItemBase64());
        if (saved != null) {
            try {
                return stripMarker(saved).isSimilar(stripMarker(item));
            } catch (Throwable ignored) {
                return false;
            }
        }
        return false;
    }

    public boolean hasBasket(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (isBasket(item)) return true;
        }
        return isBasket(player.getItemOnCursor());
    }

    /** Usuwa koszyk z ekwipunku (również ze slotów zbroi, offhandu i kursora). */
    public void remove(Player player) {
        PlayerInventory inv = player.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isBasket(contents[i])) inv.setItem(i, null);
        }
        if (isBasket(player.getItemOnCursor())) player.setItemOnCursor(null);
    }

    /** Oddanie koszyka w punkcie pobrania: bez zakupu, z wyzerowaniem koszyka. */
    public void returnBasket(Player player) {
        if (!hasBasket(player)) return;
        boolean hadItems = !plugin.cart().entries(player).isEmpty();

        remove(player);
        if (plugin.settings().basketReturnResetsCart) plugin.cart().reset(player);
        else plugin.cart().hide(player);

        plugin.messages().send(player, "basket-returned");
        if (hadItems && plugin.settings().basketReturnResetsCart) {
            plugin.messages().send(player, "basket-return-reset");
        }
        plugin.sound(player, plugin.settings().basketSound);
    }

    /**
     * Zabiera koszyk, gdy gracz oddali się od sklepu bardziej niż
     * basket.auto-remove-distance. 0 w configu = funkcja wyłączona.
     */
    public void checkDistance(Player player) {
        int radius = plugin.settings().basketAutoRemoveDistance;
        if (radius <= 0 || player == null || !player.isOnline() || !hasBasket(player)) return;

        List<Location> points = shopLocations();
        if (points.isEmpty()) return; // brak punktów sklepu - nie ma od czego liczyć

        Location from = player.getLocation();
        double nearestSq = Double.MAX_VALUE;
        for (Location point : points) {
            if (point.getWorld() == null || !point.getWorld().equals(from.getWorld())) continue;
            double d = point.distanceSquared(from);
            if (d < nearestSq) nearestSq = d;
        }

        // Punkty istnieją, ale wszystkie są w innym świecie -> gracz jest daleko.
        if (nearestSq <= (double) radius * radius) return;

        remove(player);
        plugin.cart().reset(player);
        plugin.messages().send(player, "basket-auto-removed",
                "distance", String.valueOf(radius));
        plugin.sound(player, plugin.settings().basketSound);
    }

    /** Lokalizacje wszystkich punktów sklepu: regały, kasy i punkty koszyka. */
    private List<Location> shopLocations() {
        List<Location> out = new ArrayList<>();
        for (Shelf shelf : plugin.data().all()) {
            for (String target : shelf.targets) addTarget(out, target);
        }
        for (String target : plugin.data().basketPoints()) addTarget(out, target);
        for (String target : plugin.data().checkoutPoints()) addTarget(out, target);
        return out;
    }

    private void addTarget(List<Location> out, String key) {
        Location location = Targets.locationOf(key);
        if (location != null) out.add(location);
    }

    public boolean canOpenShelf(Player player) {
        Settings s = plugin.settings();
        if (!s.basketRequired || player.hasPermission("skyrise.bypass")) return true;
        PlayerInventory inv = player.getInventory();
        if (s.basketRequireInHand) {
            return isBasket(inv.getItemInMainHand())
                    || (s.basketAllowOffhand && isBasket(inv.getItemInOffHand()));
        }
        return hasBasket(player);
    }

    /** Daje koszyk do głównej ręki. Zwraca true, gdy się udało. */
    public boolean give(Player player) {
        Settings s = plugin.settings();
        if (s.basketUnique && hasBasket(player)) {
            plugin.messages().send(player, "basket-already");
            return false;
        }

        ItemStack basket = create(player);
        if (basket == null) {
            plugin.messages().send(player, "basket-not-configured");
            plugin.sound(player, s.errorSound);
            return false;
        }

        PlayerInventory inv = player.getInventory();
        ItemStack inHand = inv.getItemInMainHand();
        if (inHand == null || inHand.isEmpty()) {
            inv.setItemInMainHand(basket);
        } else {
            int free = inv.firstEmpty();
            if (free < 0) {
                plugin.messages().send(player, "basket-no-space");
                plugin.sound(player, s.errorSound);
                return false;
            }
            inv.setItem(free, inHand);
            inv.setItemInMainHand(basket);
        }

        plugin.messages().send(player, "basket-received");
        plugin.sound(player, s.basketSound);
        plugin.cart().start(player);
        return true;
    }
}
