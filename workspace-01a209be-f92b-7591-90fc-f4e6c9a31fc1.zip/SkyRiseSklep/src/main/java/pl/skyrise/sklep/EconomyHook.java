package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Vault przez refleksję + XP + FREE + SkyRiseBank. Brak zależności compile-time. */
public final class EconomyHook {

    public enum Mode { VAULT, XP, FREE, BANK }

    private final SkyRiseSklep plugin;
    private final Settings settings;
    private final BankHook bank;

    private Object provider;
    private Method hasMethod;
    private Method withdrawMethod;
    private Method depositMethod;
    private Method balanceMethod;
    private Method formatMethod;
    private Class<?> argType;
    private Mode active = Mode.FREE;

    public EconomyHook(SkyRiseSklep plugin, Settings settings, BankHook bank) {
        this.plugin = plugin;
        this.settings = settings;
        this.bank = bank;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void setup() {
        provider = null;
        hasMethod = withdrawMethod = depositMethod = balanceMethod = formatMethod = null;
        argType = null;

        switch (settings.economyMode) {
            case "VAULT" -> {
                if (setupVault()) {
                    active = Mode.VAULT;
                    return;
                }
                if (settings.fallbackFree) {
                    active = Mode.FREE;
                    plugin.getLogger().warning("Brak dostawcy Vault - zakupy działają w trybie darmowym (economy.fallback-free: true).");
                } else {
                    active = Mode.VAULT; // provider == null -> zakupy zablokowane
                    plugin.getLogger().warning("Brak dostawcy Vault - zakupy zablokowane (economy.fallback-free: false).");
                }
            }
            case "BANK" -> {
                if (bank.available()) {
                    active = Mode.BANK;
                    plugin.getLogger().info("Płatności: SkyRiseBank (karta); podatek i zwroty też idą do banku.");
                    return;
                }
                plugin.getLogger().warning("Brak SkyRiseBank/API - fallback: " + settings.bankFallback);
                if ("NONE".equals(settings.bankFallback)) {
                    active = Mode.BANK; // isAvailable() = false -> zakupy zablokowane
                    return;
                }
                if ("FREE".equals(settings.bankFallback)) {
                    active = Mode.FREE;
                    return;
                }
                if (setupVault()) {
                    active = Mode.VAULT;
                    return;
                }
                active = settings.fallbackFree ? Mode.FREE : Mode.VAULT;
            }
            case "XP" -> active = Mode.XP;
            case "FREE" -> active = Mode.FREE;
            default -> {
                active = Mode.FREE;
                plugin.getLogger().warning("Nieznany economy.mode: " + settings.economyMode + " - używam FREE.");
            }
        }
    }

    private boolean setupVault() {
        try {
            Class<?> api = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider<?> rsp = Bukkit.getServicesManager().getRegistration((Class) api);
            if (rsp == null || rsp.getProvider() == null) return false;
            provider = rsp.getProvider();

            for (Class<?> candidate : new Class<?>[]{OfflinePlayer.class, String.class}) {
                try {
                    hasMethod = api.getMethod("has", candidate, double.class);
                    withdrawMethod = api.getMethod("withdrawPlayer", candidate, double.class);
                    depositMethod = api.getMethod("depositPlayer", candidate, double.class);
                    balanceMethod = api.getMethod("getBalance", candidate);
                    argType = candidate;
                    break;
                } catch (NoSuchMethodException ignored) {
                    // starsza wersja Vault używa String zamiast OfflinePlayer
                }
            }
            if (argType == null) {
                provider = null;
                return false;
            }
            try {
                formatMethod = api.getMethod("format", double.class);
            } catch (NoSuchMethodException ignored) {
                formatMethod = null;
            }
            plugin.getLogger().info("Podłączono ekonomię Vault (" + rsp.getPlugin().getName() + ").");
            return true;
        } catch (Throwable t) {
            provider = null;
            return false;
        }
    }

    public boolean isAvailable() {
        return switch (active) {
            case VAULT -> provider != null;
            case BANK -> bank.available();
            default -> true;
        };
    }

    public boolean isFree() {
        return active == Mode.FREE;
    }

    /** Czy faktycznie płacimy przez bezpośrednie API SkyRiseBank (asynchronicznie). */
    public boolean isBankActive() {
        return active == Mode.BANK && bank.available();
    }

    public String status() {
        if (active == Mode.VAULT) return provider == null ? "VAULT (brak dostawcy)" : "VAULT";
        if (active == Mode.BANK) return bank.status();
        return active.name();
    }

    private Object arg(Player player) {
        return argType == OfflinePlayer.class ? (OfflinePlayer) player : player.getName();
    }

    public boolean has(Player player, double amount) {
        if (amount <= 0) return true;
        return switch (active) {
            case VAULT -> {
                if (provider == null) yield false;
                try {
                    Object r = hasMethod.invoke(provider, arg(player), amount);
                    yield r instanceof Boolean b && b;
                } catch (Throwable t) {
                    yield false;
                }
            }
            case BANK -> {
                if (!bank.available() || bank.isFrozen(player.getUniqueId())) yield false;
                Double cached = bank.cachedBalance(player.getUniqueId());
                // Brak cache nie blokuje - ostatecznie decyduje withdraw() w API banku.
                yield cached == null || cached >= amount;
            }
            case XP -> player.getLevel() >= (int) Math.ceil(amount);
            case FREE -> true;
        };
    }

    public boolean withdraw(Player player, double amount) {
        if (amount <= 0) return true;
        return switch (active) {
            case VAULT -> {
                if (provider == null) yield false;
                try {
                    Object response = withdrawMethod.invoke(provider, arg(player), amount);
                    if (response == null) yield true;
                    Method success = response.getClass().getMethod("transactionSuccess");
                    Object value = success.invoke(response);
                    yield !(value instanceof Boolean b) || b;
                } catch (Throwable t) {
                    yield false;
                }
            }
            case XP -> {
                int cost = (int) Math.ceil(amount);
                int level = player.getLevel();
                if (level < cost) yield false;
                player.setLevel(level - cost);
                yield true;
            }
            case BANK -> false; // płatność idzie asynchronicznie przez BankHook.withdraw()
            case FREE -> true;
        };
    }

    public void deposit(Player player, double amount) {
        if (amount <= 0) return;
        switch (active) {
            case VAULT -> {
                if (provider == null) return;
                try {
                    depositMethod.invoke(provider, arg(player), amount);
                } catch (Throwable ignored) {
                    // nic więcej nie możemy zrobić
                }
            }
            case XP -> player.setLevel(player.getLevel() + (int) Math.ceil(amount));
            case BANK -> bank.deposit(player.getUniqueId(), amount, "SkyRiseSklep - zwrot", null);
            case FREE -> {
                // brak środków do zwrotu
            }
        }
    }

    /** Przelew podatku na wskazany nick (Vault albo konto bankowe). */
    public boolean transferTo(String playerName, double amount) {
        if (amount <= 0 || playerName == null || playerName.isBlank()) return false;
        if (active == Mode.BANK) return bank.depositToName(playerName, amount);
        if (active != Mode.VAULT || provider == null) return false;
        try {
            Object arg = argType == OfflinePlayer.class ? Bukkit.getOfflinePlayer(playerName) : playerName;
            depositMethod.invoke(provider, arg, amount);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public double balance(Player player) {
        if (active == Mode.VAULT && provider != null) {
            try {
                Object value = balanceMethod.invoke(provider, arg(player));
                if (value instanceof Number n) return n.doubleValue();
            } catch (Throwable ignored) {
                // zwróć 0
            }
        }
        if (active == Mode.BANK) {
            Double cached = bank.cachedBalance(player.getUniqueId());
            return cached == null ? 0 : cached;
        }
        return active == Mode.XP ? player.getLevel() : 0;
    }

    public String format(double amount) {
        if (active == Mode.BANK) return bank.format(amount);
        if (active == Mode.XP) return (int) Math.ceil(amount) + " " + settings.xpLabel;
        if (active == Mode.VAULT && formatMethod != null && provider != null) {
            try {
                Object value = formatMethod.invoke(provider, amount);
                if (value instanceof String s) return s;
            } catch (Throwable ignored) {
                // fallback poniżej
            }
        }
        DecimalFormat df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pl-PL")));
        return df.format(amount) + " " + settings.currencySymbol;
    }

    public String balanceText(Player player) {
        return format(balance(player));
    }
}
