package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

/** /srs - komendy gracza i administratora (pod TAB-em głównie po polsku). */
public final class Commands implements CommandExecutor, TabCompleter {

    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_-]{1,32}$");

    public static boolean validShelfName(String name) {
        return name != null && VALID_NAME.matcher(name).matches();
    }

    private static final List<String> TAB_SUBCOMMANDS = List.of(
            "pomoc", "informacje", "przeladuj", "lista", "anuluj", "dajkoszyk", "koszyk",
            "ustawkoszyk", "usunkoszyk", "ustawkase", "usunkase", "nowapolka",
            "dodajregal", "usunregal", "edytuj", "usun", "cena", "domyslna",
            "zaplac", "wyczysc", "widok", "panel", "promocje");

    private static final Set<String> SHELF_ARG = Set.of(
            "dodajregal", "usunregal", "edytuj", "usun", "cena", "domyslna",
            "addshelf", "removeshelf", "edit", "delete", "price", "defaultprice");

    private final SkyRiseSklep plugin;

    public Commands(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "pomoc" : args[0].toLowerCase(Locale.ROOT);
        Messages msg = plugin.messages();

        switch (sub) {
            case "help", "pomoc" -> help(sender);
            case "info", "informacje" -> info(sender);
            case "reload", "przeladuj" -> {
                if (!admin(sender)) return true;
                plugin.reloadAll();
                msg.send(sender, "reloaded");
            }
            case "lista", "list" -> {
                if (!admin(sender)) return true;
                list(sender);
            }
            case "anuluj", "cancel" -> {
                Player p = requirePlayer(sender);
                if (p == null) return true;
                if (plugin.listeners().cancel(p)) msg.send(p, "selection-cancelled");
                else msg.send(p, "selection-none");
            }
            case "dajkoszyk", "givebasket" -> {
                if (!admin(sender)) return true;
                giveBasket(sender, args);
            }
            case "koszyk", "setbasketitem" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                saveBasketItem(p);
            }
            case "ustawkoszyk", "setbasket" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.BASKET_ADD, null, "selection-basket-add");
            }
            case "usunkoszyk", "delbasket" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.BASKET_REMOVE, null, "selection-basket-remove");
            }
            case "ustawkase", "setcheckout" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.CHECKOUT_ADD, null, "selection-checkout-add");
            }
            case "usunkase", "delcheckout" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.CHECKOUT_REMOVE, null, "selection-checkout-remove");
            }
            case "panel", "admin", "adminpanel" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.adminPanel().openMain(p);
            }
            case "promocje", "promotions" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                plugin.adminPanel().openPromotions(p);
            }
            case "zaplac", "kasa", "pay", "checkout" -> {
                Player p = requirePlayer(sender);
                if (p == null) return true;
                checkout(p);
            }
            case "wyczysc", "clearcart" -> {
                Player p = requirePlayer(sender);
                if (p == null) return true;
                if (!p.hasPermission("skyrise.use")) {
                    msg.send(p, "no-permission", "permission", "skyrise.use");
                    return true;
                }
                plugin.cart().clear(p);
                msg.send(p, "cart-cleared");
            }
            case "widok", "scoreboard", "koszykwidok" -> {
                Player p = requirePlayer(sender);
                if (p == null) return true;
                if (!p.hasPermission("skyrise.use")) {
                    msg.send(p, "no-permission", "permission", "skyrise.use");
                    return true;
                }
                plugin.cart().toggle(p);
            }
            case "nowapolka", "createshelf" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                if (args.length < 2) { usage(sender, "/srs nowapolka <nazwa>"); return true; }
                String name = args[1];
                if (!VALID_NAME.matcher(name).matches()) { msg.send(sender, "shelf-invalid-name"); return true; }
                if (plugin.data().getShelf(name) != null) { msg.send(sender, "shelf-exists", "shelf", name); return true; }
                plugin.listeners().select(p, Listeners.SelectionType.SHELF_CREATE, name, "selection-shelf-create");
            }
            case "dodajregal", "addshelf" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                Shelf shelf = shelfArg(sender, args);
                if (shelf == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.SHELF_ADD, shelf.name, "selection-shelf-add");
            }
            case "usunregal", "removeshelf" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                Shelf shelf = shelfArg(sender, args);
                if (shelf == null) return true;
                plugin.listeners().select(p, Listeners.SelectionType.SHELF_REMOVE, shelf.name, "selection-shelf-remove");
            }
            case "edytuj", "edit" -> {
                if (!admin(sender)) return true;
                Player p = requirePlayer(sender);
                if (p == null) return true;
                Shelf shelf = shelfArg(sender, args);
                if (shelf == null) return true;
                plugin.gui().openEditor(p, shelf);
            }
            case "usun", "delete" -> {
                if (!admin(sender)) return true;
                Shelf shelf = shelfArg(sender, args);
                if (shelf == null) return true;
                plugin.data().removeShelf(shelf.name);
                plugin.data().save();
                msg.send(sender, "shelf-deleted", "shelf", shelf.name);
            }
            case "cena", "price" -> {
                if (!admin(sender)) return true;
                setPrice(sender, args);
            }
            case "domyslna", "defaultprice" -> {
                if (!admin(sender)) return true;
                setDefaultPrice(sender, args);
            }
            default -> msg.send(sender, "unknown-command");
        }
        return true;
    }

    private void help(CommandSender sender) {
        Messages msg = plugin.messages();
        Settings s = plugin.settings();
        msg.separator(sender);
        for (String line : msg.rawList("help-player")) {
            // Nie pokazuj linii o dystansie, gdy funkcja jest wyłączona.
            if (line.contains("{distance}") && s.basketAutoRemoveDistance <= 0) continue;
            if (line.contains("{radius}") && s.shelfRadius <= 0) continue;
            msg.line(sender, line,
                    "bulk", String.valueOf(s.bulkAmount),
                    "distance", String.valueOf(s.basketAutoRemoveDistance),
                    "radius", String.valueOf(s.shelfRadius));
        }
        if (sender.hasPermission("skyrise.admin")) {
            msg.separator(sender);
            msg.lines(sender, "help-admin");
        }
        msg.separator(sender);
    }

    private void checkout(Player player) {
        Messages msg = plugin.messages();
        if (!player.hasPermission("skyrise.use")) {
            msg.send(player, "no-permission", "permission", "skyrise.use");
            return;
        }
        if (plugin.settings().checkoutMode.equals("INSTANT")) {
            msg.send(player, "checkout-disabled");
            return;
        }
        if (plugin.data().checkoutPoints().isEmpty()) {
            msg.send(player, "checkout-no-points");
            return;
        }
        if (!nearCheckout(player)) {
            msg.send(player, "checkout-too-far");
            return;
        }
        if (plugin.settings().checkoutRequireBasket && !plugin.baskets().canOpenShelf(player)) {
            msg.send(player, "checkout-need-basket");
            return;
        }
        plugin.gui().openCheckout(player);
    }

    private boolean nearCheckout(Player player) {
        double radiusSq = (double) plugin.settings().checkoutRadius * plugin.settings().checkoutRadius;
        Location from = player.getLocation();
        for (String key : plugin.data().checkoutPoints()) {
            if (key.startsWith("block|")) {
                String[] parts = key.split("\\|", 6);
                if (parts.length != 5) continue;
                World world = Bukkit.getWorld(parts[1]);
                if (world == null || !player.getWorld().equals(world)) continue;
                try {
                    Location loc = new Location(world,
                            Double.parseDouble(parts[2]) + 0.5,
                            Double.parseDouble(parts[3]) + 0.5,
                            Double.parseDouble(parts[4]) + 0.5);
                    if (loc.distanceSquared(from) <= radiusSq) return true;
                } catch (NumberFormatException ignored) {
                    // błędny wpis - pomiń
                }
            } else if (key.startsWith("entity|")) {
                try {
                    Entity entity = Bukkit.getEntity(UUID.fromString(key.substring(7)));
                    if (entity != null && entity.getWorld().equals(player.getWorld())
                            && entity.getLocation().distanceSquared(from) <= radiusSq) return true;
                } catch (IllegalArgumentException ignored) {
                    // błędny UUID - pomiń
                }
            }
        }
        return false;
    }

    private void info(CommandSender sender) {
        Messages msg = plugin.messages();
        DataStore data = plugin.data();
        msg.send(sender, "info-header");
        msg.send(sender, "info-line", "key", "Wersja", "value", "1.0.0 (Purpur/Paper 1.21.10)");
        msg.send(sender, "info-line", "key", "Nexo", "value", plugin.nexo().available() ? "wykryto" : "brak (fallback / zapisany item)");
        msg.send(sender, "info-line", "key", "Ekonomia", "value", plugin.economy().status());
        msg.send(sender, "info-line", "key", "SkyRiseBank", "value", plugin.bank().available()
                ? (plugin.settings().checkoutCardEnabled ? "karta + PIN w kasie" : "wykryto, przycisk karty off")
                : "brak pluginu/API");
        msg.send(sender, "info-line", "key", "Tryb zakupu", "value", plugin.settings().checkoutMode.equals("INSTANT") ? "natychmiastowy" : "kasa");
        msg.send(sender, "info-line", "key", "Zasięg regału",
                "value", plugin.settings().shelfRadius > 0
                        ? "±" + plugin.settings().shelfRadius + " bloków w każdą stronę"
                        : "tylko zaznaczony punkt");
        msg.send(sender, "info-line", "key", "Promocje", "value", plugin.promotions().status());
        msg.send(sender, "info-line", "key", "Podatek",
                "value", plugin.settings().taxEnabled
                        ? Math.round(plugin.settings().taxRate * 100) + "% -> " +
                        (plugin.settings().taxReceiver.isBlank() ? "brak odbiorcy" : plugin.settings().taxReceiver)
                        : "wyłączony");
        Settings s = plugin.settings();
        String scoreboardState = !(s.cartEnabled || s.cartShowOnBasket || s.cartToggleCommand)
                ? "wyłączony"
                : (s.cartEnabled ? "zawsze włączony" : "domyślnie wyłączony, pojawia się przy koszyku");
        msg.send(sender, "info-line", "key", "Scoreboard koszyka", "value", scoreboardState);
        msg.send(sender, "info-line", "key", "Silnik scoreboardu", "value", plugin.tab().status());
        msg.send(sender, "info-line", "key", "Oddawanie koszyka",
                "value", s.basketReturnOnReclick ? "klik w punkt pobrania" : "wyłączone");
        msg.send(sender, "info-line", "key", "Auto-usuwanie koszyka",
                "value", s.basketAutoRemoveDistance > 0 ? s.basketAutoRemoveDistance + " kratek" : "wyłączone");
        msg.send(sender, "info-line", "key", "Koszyk", "value", data.basketItemBase64().isBlank()
                ? "ID Nexo: " + plugin.settings().basketNexoId : "zapisany przedmiot z data.yml");
        msg.send(sender, "info-line", "key", "Regały", "value", String.valueOf(data.all().size()));
        msg.send(sender, "info-line", "key", "Punkty koszyka", "value", String.valueOf(data.basketPoints().size()));
        msg.send(sender, "info-line", "key", "Kasy", "value", String.valueOf(data.checkoutPoints().size()));
    }

    private void list(CommandSender sender) {
        Messages msg = plugin.messages();
        Collection<Shelf> shelves = plugin.data().all();
        msg.send(sender, "list-header");
        if (shelves.isEmpty()) {
            msg.send(sender, "list-empty");
        } else {
            for (Shelf s : shelves) {
                msg.send(sender, "list-line",
                        "name", s.name,
                        "items", String.valueOf(s.items.size()),
                        "targets", String.valueOf(s.targets.size()));
            }
        }
        msg.send(sender, "basket-points-header");
        printPoints(sender, plugin.data().basketPoints(), "basket-point-line", "basket-points-empty");
        msg.send(sender, "checkout-points-header");
        printPoints(sender, plugin.data().checkoutPoints(), "checkout-point-line", "checkout-points-empty");
    }

    private void printPoints(CommandSender sender, Set<String> points, String lineKey, String emptyKey) {
        if (points.isEmpty()) {
            plugin.messages().send(sender, emptyKey);
            return;
        }
        for (String target : points) {
            plugin.messages().send(sender, lineKey, "target", Targets.describe(target));
        }
    }

    private void giveBasket(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                plugin.messages().send(sender, "player-not-found", "player", args[1]);
                return;
            }
        } else {
            target = requirePlayer(sender);
            if (target == null) return;
        }
        if (plugin.baskets().give(target) && target != sender) {
            plugin.messages().send(sender, "basket-given-other", "player", target.getName());
        }
    }

    private void saveBasketItem(Player player) {
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held == null || held.isEmpty()) {
            plugin.messages().send(player, "basket-hold-item");
            return;
        }
        String encoded = DataStore.encode(held);
        if (encoded == null) {
            plugin.messages().send(player, "basket-save-failed");
            return;
        }
        plugin.data().setBasketItemBase64(encoded);
        plugin.data().save();
        plugin.messages().send(player, "basket-saved", "item", Util.itemName(held));
    }

    private void setPrice(CommandSender sender, String[] args) {
        Messages msg = plugin.messages();
        if (args.length < 4) { usage(sender, "/srs cena <nazwa> <slot 1-45> <kwota>"); return; }
        Shelf shelf = plugin.data().getShelf(args[1]);
        if (shelf == null) { msg.send(sender, "shelf-missing", "shelf", args[1]); return; }
        Integer slot = parseSlot(args[2]);
        if (slot == null) { msg.send(sender, "slot-invalid"); return; }
        Double value = Util.parseNumber(args[3]);
        if (value == null || value < 0) { msg.send(sender, "price-invalid"); return; }
        shelf.prices.put(slot - 1, value);
        plugin.data().save();
        msg.send(sender, "price-set",
                "shelf", shelf.name,
                "slot", String.valueOf(slot),
                "price", plugin.economy().format(value));
    }

    private void setDefaultPrice(CommandSender sender, String[] args) {
        Messages msg = plugin.messages();
        if (args.length < 3) { usage(sender, "/srs domyslna <nazwa> <kwota>"); return; }
        Shelf shelf = plugin.data().getShelf(args[1]);
        if (shelf == null) { msg.send(sender, "shelf-missing", "shelf", args[1]); return; }
        Double value = Util.parseNumber(args[2]);
        if (value == null || value < 0) { msg.send(sender, "price-invalid"); return; }
        shelf.defaultPrice = value;
        plugin.data().save();
        msg.send(sender, "price-default-set", "shelf", shelf.name, "price", plugin.economy().format(value));
    }

    private Shelf shelfArg(CommandSender sender, String[] args) {
        if (args.length < 2) {
            usage(sender, "/srs " + args[0] + " <nazwa>");
            return null;
        }
        Shelf shelf = plugin.data().getShelf(args[1]);
        if (shelf == null) plugin.messages().send(sender, "shelf-missing", "shelf", args[1]);
        return shelf;
    }

    private static Integer parseSlot(String raw) {
        try {
            int slot = Integer.parseInt(raw.trim());
            return slot >= 1 && slot <= GuiManager.ITEM_SLOTS ? slot : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private boolean admin(CommandSender sender) {
        if (sender.hasPermission("skyrise.admin")) return true;
        plugin.messages().send(sender, "no-permission", "permission", "skyrise.admin");
        return false;
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player player) return player;
        plugin.messages().send(sender, "player-only");
        return null;
    }

    private void usage(CommandSender sender, String text) {
        plugin.messages().send(sender, "usage", "usage", text);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        boolean admin = sender.hasPermission("skyrise.admin");
        List<String> available = admin ? TAB_SUBCOMMANDS
                : List.of("pomoc", "informacje", "anuluj", "zaplac", "wyczysc", "widok");
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> out = new ArrayList<>();
            for (String sub : available) if (sub.startsWith(prefix)) out.add(sub);
            return out;
        }
        if (!admin) return List.of();
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && SHELF_ARG.contains(sub)) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> out = new ArrayList<>();
            for (Shelf shelf : plugin.data().all()) {
                if (shelf.name.toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(shelf.name);
            }
            return out;
        }
        if (args.length == 2 && (sub.equals("dajkoszyk") || sub.equals("givebasket"))) {
            List<String> out = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) out.add(player.getName());
            return out;
        }
        return List.of();
    }
}
