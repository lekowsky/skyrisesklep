package pl.skyrise.sklep;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.DialogRegistryEntry;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Dialog PIN-u (Paper Dialogs API). Nie da się go zamknąć klawiszem Escape -
 * płatność kartą przechodzi dopiero po poprawnym PIN-ie albo przez "Anuluj".
 */
public final class PinPrompt {

    private static final String INPUT_KEY = "skyrise_sklep_pin";

    private final SkyRiseSklep plugin;
    private final Map<UUID, Session> sessions = new HashMap<>();

    private static final class Session {
        private final String total;
        private final String card;
        private final Runnable onSuccess;
        private final Runnable onCancel;
        private int attemptsLeft;
        private boolean busy;

        private Session(String total, String card, Runnable onSuccess, Runnable onCancel, int attemptsLeft) {
            this.total = total;
            this.card = card;
            this.onSuccess = onSuccess;
            this.onCancel = onCancel;
            this.attemptsLeft = attemptsLeft;
        }
    }

    public PinPrompt(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    /** Otwiera dialog PIN-u; onSuccess wołany dopiero po poprawnej weryfikacji. */
    public void open(Player player, String total, String card, Runnable onSuccess, Runnable onCancel) {
        if (player == null || !player.isOnline()) return;
        Session session = new Session(total, card, onSuccess, onCancel,
                Math.max(1, plugin.settings().pinMaxAttempts));
        sessions.put(player.getUniqueId(), session);
        show(player, session, null);
    }

    private Component pinError(String key, String... kv) {
        return Util.color(Util.replace(plugin.messages().raw(key), kv));
    }

    /** Długość PIN-u: config sklepu albo banking.pin.length z SkyRiseBank. */
    private int pinLength() {
        int configured = plugin.settings().pinLength;
        if (configured > 0) return configured;
        return plugin.bank().available() ? plugin.bank().pinLength() : 4;
    }

    public void cancel(Player player) {
        if (player == null) return;
        Session session = sessions.remove(player.getUniqueId());
        if (session != null && session.onCancel != null) session.onCancel.run();
    }

    /** Anuluje wszystkie otwarte dialogi (przeładowanie / wyłączenie pluginu). */
    public void cancelAll() {
        for (Session session : new ArrayList<>(sessions.values())) {
            if (session.onCancel != null) session.onCancel.run();
        }
        sessions.clear();
    }

    private void show(Player player, Session session, Component errorLine) {
        if (!plugin.isEnabled() || !player.isOnline()) return;
        Settings s = plugin.settings();

        List<DialogBody> body = new ArrayList<>();
        if (errorLine != null) {
            body.add(DialogBody.plainMessage(errorLine));
            body.add(DialogBody.plainMessage(Component.empty()));
        }
        body.add(DialogBody.plainMessage(Util.color(Util.replace(s.pinBody,
                "total", session.total, "card", session.card))));

        DialogInput input = DialogInput.text(INPUT_KEY, Util.color(s.pinLabel))
                .maxLength(pinLength())
                .width(200)
                .initial("")
                .build();

        DialogBase base = DialogBase.builder(Util.color(s.pinTitle))
                .canCloseWithEscape(false) // wymuszenie wpisania PIN-u
                .body(body)
                .inputs(List.of(input))
                .build();

        ClickCallback.Options options = ClickCallback.Options.builder().uses(1).build();

        ActionButton submit = ActionButton.create(
                Util.color(s.pinSubmit),
                Util.color("&7Zatwierdź PIN i zapłać kartą."),
                100,
                DialogAction.customClick((DialogResponseView response, net.kyori.adventure.audience.Audience audience) -> {
                    String raw = response == null ? "" : response.getText(INPUT_KEY);
                    String pin = raw == null ? "" : raw.trim();
                    onMain(() -> handle(player, session, pin));
                }, options));

        ActionButton cancel = ActionButton.create(
                Util.color(s.pinCancel),
                Util.color("&7Rezygnuję z płatności kartą."),
                100,
                DialogAction.customClick((DialogResponseView response, net.kyori.adventure.audience.Audience audience) ->
                        onMain(() -> {
                            if (sessions.get(player.getUniqueId()) != session) return;
                            sessions.remove(player.getUniqueId());
                            plugin.messages().send(player, "card-pin-cancelled");
                            if (session.onCancel != null) session.onCancel.run();
                        }), options));

        try {
            Dialog dialog = Dialog.create(factory -> {
                DialogRegistryEntry.Builder builder = factory.empty();
                builder.base(base).type(DialogType.multiAction(List.of(submit), cancel, 2));
            });
            player.closeInventory();
            player.showDialog(dialog);
        } catch (Throwable t) {
            // Starszy serwer bez Dialogs API - nie wolno przepuścić płatności bez PIN-u.
            sessions.remove(player.getUniqueId());
            plugin.messages().send(player, "card-pin-error");
            if (session.onCancel != null) session.onCancel.run();
            plugin.getLogger().warning("Nie udało się otworzyć dialogu PIN-u: " + t.getClass().getSimpleName());
        }
    }

    private void handle(Player player, Session session, String pin) {
        if (!player.isOnline() || sessions.get(player.getUniqueId()) != session || session.busy) return;

        if (pin.isEmpty() || !pin.chars().allMatch(Character::isDigit)) {
            // Błąd jest widoczny w dialogu - nie dublujemy go na czacie.
            show(player, session, pinError("card-pin-digits"));
            return;
        }
        int length = pinLength();
        if (pin.length() != length) {
            show(player, session, pinError("card-pin-length", "length", String.valueOf(length)));
            return;
        }

        session.busy = true;
        plugin.bank().verifyPin(player, pin, result -> {
            if (sessions.get(player.getUniqueId()) != session) return;
            session.busy = false;
            switch (result) {
                case OK -> {
                    sessions.remove(player.getUniqueId());
                    player.closeDialog();
                    if (session.onSuccess != null) session.onSuccess.run();
                }
                case WRONG -> {
                    session.attemptsLeft--;
                    if (session.attemptsLeft <= 0) {
                        sessions.remove(player.getUniqueId());
                        player.closeDialog();
                        plugin.messages().send(player, "card-pin-locked");
                        if (session.onCancel != null) session.onCancel.run();
                    } else {
                        show(player, session, pinError("card-pin-wrong",
                                "left", String.valueOf(session.attemptsLeft)));
                    }
                }
                case NO_PIN -> {
                    sessions.remove(player.getUniqueId());
                    player.closeDialog();
                    plugin.messages().send(player, "card-no-pin");
                    if (session.onCancel != null) session.onCancel.run();
                }
                case NO_ACCOUNT -> {
                    sessions.remove(player.getUniqueId());
                    player.closeDialog();
                    plugin.messages().send(player, "card-no-account");
                    if (session.onCancel != null) session.onCancel.run();
                }
                default -> {
                    sessions.remove(player.getUniqueId());
                    player.closeDialog();
                    plugin.messages().send(player, "card-pin-error");
                    if (session.onCancel != null) session.onCancel.run();
                }
            }
        });
    }

    private void onMain(Runnable runnable) {
        if (!plugin.isEnabled()) return;
        try {
            Bukkit.getScheduler().runTask(plugin, runnable);
        } catch (Throwable ignored) {
            // plugin wyłączony
        }
    }
}
