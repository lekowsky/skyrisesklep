package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Integracja z SkyRiseBank przez publiczne API (SkyRiseBankProvider / SkyRiseBankAPI)
 * oraz rozpoznawanie karty bankomatowej (PDC skyrisebank:bank_card).
 *
 * Wszystko przez refleksję - brak zależności compile-time, plugin działa bez banku.
 * Operacje bankowe są asynchroniczne (CompletableFuture); wyniki wracają na główny wątek.
 */
public final class BankHook {

    /** Wynik operacji pobrania środków. */
    public record ChargeResult(boolean success, String status, double balance) {
    }

    /** Wynik weryfikacji PIN-u karty. */
    public enum PinResult { OK, WRONG, NO_PIN, NO_ACCOUNT, ERROR }

    private static final NamespacedKey CARD_MARKER = new NamespacedKey("skyrisebank", "bank_card");
    private static final NamespacedKey CARD_OWNER = new NamespacedKey("skyrisebank", "bank_card_owner");
    private static final NamespacedKey CARD_SERIAL = new NamespacedKey("skyrisebank", "bank_card_serial");
    private static final NamespacedKey CARD_NUMBER = new NamespacedKey("skyrisebank", "bank_card_number");

    private final SkyRiseSklep plugin;

    private boolean available;
    private Object api;
    private Object bankPlugin;
    private Method withdrawMethod;
    private Method depositMethod;
    private Method cachedBalanceMethod;
    private Method isFrozenMethod;
    private Method resultSuccess;
    private Method resultStatus;
    private Method resultBalance;
    private Method isCardMethod;
    private Method ownerOfMethod;
    private Method serialOfMethod;

    private boolean cardReady;
    private Object bankAccounts;
    private Object personalType;
    private Method findAccountMethod;
    private Method hasPinMethod;
    private Method verifyPinMethod;
    private Method cardWithdrawMethod;
    private Method cardDepositMethod;
    private Method cardTxSuccess;
    private Method cardTxBalance;
    private Method cardTxError;

    private String symbol = "$";
    private String pattern = "#,##0.00";
    private boolean symbolPrefix = true;
    private int bankPinLength = 4;

    public BankHook(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    public void init() {
        available = false;
        api = null;
        bankPlugin = null;
        withdrawMethod = depositMethod = cachedBalanceMethod = isFrozenMethod = null;
        resultSuccess = resultStatus = resultBalance = null;
        isCardMethod = ownerOfMethod = serialOfMethod = null;
        cardReady = false;
        bankAccounts = personalType = null;
        findAccountMethod = hasPinMethod = verifyPinMethod = null;
        cardWithdrawMethod = cardDepositMethod = null;
        cardTxSuccess = cardTxBalance = cardTxError = null;

        try {
            bankPlugin = Bukkit.getPluginManager().getPlugin("SkyRiseBank");
            if (bankPlugin == null) return;

            Class<?> provider = Class.forName("pl.skyrise.bank.api.SkyRiseBankProvider");
            Object instance = null;
            try {
                instance = provider.getMethod("get").invoke(null);
            } catch (Throwable ignored) {
                // get() może rzucić, gdy API nie jest jeszcze zarejestrowane
            }
            if (instance == null) {
                try {
                    Object optional = provider.getMethod("getOptional").invoke(null);
                    if (optional instanceof Optional<?> opt && opt.isPresent()) instance = opt.get();
                } catch (Throwable ignored) {
                    // starsza wersja API bez getOptional()
                }
            }
            if (instance == null) return;
            api = instance;

            Class<?> apiClass = Class.forName("pl.skyrise.bank.bank.SkyRiseBankAPI");
            withdrawMethod = apiClass.getMethod("withdraw", UUID.class, BigDecimal.class, String.class);
            depositMethod = apiClass.getMethod("deposit", UUID.class, BigDecimal.class, String.class);
            cachedBalanceMethod = apiClass.getMethod("getCachedBalance", UUID.class);
            isFrozenMethod = apiClass.getMethod("isFrozen", UUID.class);

            Class<?> resultClass = Class.forName("pl.skyrise.bank.bank.BankResult");
            resultSuccess = resultClass.getMethod("success");
            resultStatus = resultClass.getMethod("status");
            resultBalance = resultClass.getMethod("balance");

            Class<?> cardClass = Class.forName("pl.skyrise.bank.card.BankCard");
            isCardMethod = find(cardClass, "isCard", 2);
            ownerOfMethod = find(cardClass, "ownerOf", 2);
            serialOfMethod = find(cardClass, "serialOf", 2);

            readCurrency();
            available = true;
            initCard();
            plugin.getLogger().info("Wykryto SkyRiseBank - płatności kartą dostępne.");
        } catch (Throwable t) {
            plugin.getLogger().warning("SkyRiseBank wykryty, ale API jest niedostępne ("
                    + t.getClass().getSimpleName() + ") - użyję fallbacku z economy.bank.fallback.");
        }
    }

    public boolean available() {
        return available;
    }

    public String status() {
        return available ? "SkyRiseBank (portfel + karta)" : "SkyRiseBank (brak API)";
    }

    private void readCurrency() {
        if (!(bankPlugin instanceof JavaPlugin javaPlugin)) return;
        try {
            var cfg = javaPlugin.getConfig();
            symbol = cfg.getString("currency.symbol", "$");
            pattern = cfg.getString("currency.format", "#,##0.00");
            symbolPrefix = !"SUFFIX".equalsIgnoreCase(cfg.getString("currency.symbol-position", "PREFIX"));
            bankPinLength = Math.max(1, cfg.getInt("banking.pin.length", 4));
        } catch (Throwable ignored) {
            // domyślne wartości
        }
    }

    /** Formatowanie kwoty zgodne z walutą SkyRiseBank. */
    public String format(double amount) {
        try {
            DecimalFormat df = new DecimalFormat(pattern, DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pl-PL")));
            String value = df.format(amount);
            return symbolPrefix ? symbol + value : value + symbol;
        } catch (Throwable t) {
            DecimalFormat df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pl-PL")));
            return df.format(amount) + " " + symbol;
        }
    }

    // ------------------------------------------------------------------ KARTA

    /** Czy gracz ma w ekwipunku swoją (nie cudzą) kartę bankomatową. */
    public boolean hasValidCard(Player player) {
        if (player == null) return false;
        Settings s = plugin.settings();
        if (s.bankCardInHand) {
            return isOwnCard(player, player.getInventory().getItemInMainHand())
                    || isOwnCard(player, player.getInventory().getItemInOffHand());
        }
        for (ItemStack item : player.getInventory().getContents()) {
            if (isOwnCard(player, item)) return true;
        }
        return isOwnCard(player, player.getItemOnCursor());
    }

    /** Czy gracz w ogóle ma kartę (także cudzą) - do odróżnienia komunikatów. */
    public boolean hasAnyCard(Player player) {
        if (player == null) return false;
        if (plugin.settings().bankCardInHand) {
            return isCard(player.getInventory().getItemInMainHand())
                    || isCard(player.getInventory().getItemInOffHand());
        }
        for (ItemStack item : player.getInventory().getContents()) {
            if (isCard(item)) return true;
        }
        return isCard(player.getItemOnCursor());
    }

    /** Zamaskowany numer karty do GUI, np. "•••• 4821". */
    public String cardLabel(Player player) {
        if (player == null) return "karta";
        for (ItemStack item : player.getInventory().getContents()) {
            if (!isOwnCard(player, item)) continue;
            String raw = serialOf(item);
            if (raw == null || raw.isBlank()) raw = pdc(item, CARD_NUMBER);
            if (raw == null || raw.isBlank()) raw = pdc(item, CARD_SERIAL);
            if (raw == null || raw.isBlank()) return "karta";
            String clean = raw.replaceAll("[^0-9A-Za-z]", "");
            String last = clean.length() > 4 ? clean.substring(clean.length() - 4) : clean;
            return last.isEmpty() ? "karta" : "•••• " + last;
        }
        return "karta";
    }

    private boolean isOwnCard(Player player, ItemStack item) {
        if (item == null || item.isEmpty() || !isCard(item)) return false;
        if (plugin.settings().bankAllowForeignCard) return true;
        UUID owner = ownerOf(item);
        return owner == null || owner.equals(player.getUniqueId());
    }

    private boolean isCard(ItemStack item) {
        if (item == null || item.isEmpty()) return false;
        if (isCardMethod != null && bankPlugin != null) {
            try {
                Object result = isCardMethod.invoke(null, bankPlugin, item);
                if (result instanceof Boolean b) return b;
            } catch (Throwable ignored) {
                // fallback na PDC poniżej
            }
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(CARD_MARKER, PersistentDataType.BYTE);
    }

    private UUID ownerOf(ItemStack item) {
        if (ownerOfMethod != null && bankPlugin != null) {
            try {
                Object result = ownerOfMethod.invoke(null, bankPlugin, item);
                if (result instanceof Optional<?> opt && opt.orElse(null) instanceof UUID uuid) return uuid;
            } catch (Throwable ignored) {
                // fallback na PDC poniżej
            }
        }
        String raw = pdc(item, CARD_OWNER);
        if (raw == null || raw.isBlank()) return null;
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private String serialOf(ItemStack item) {
        if (serialOfMethod != null && bankPlugin != null) {
            try {
                Object result = serialOfMethod.invoke(null, bankPlugin, item);
                if (result instanceof Optional<?> opt && opt.orElse(null) instanceof String s) return s;
            } catch (Throwable ignored) {
                // brak numeru - użyjemy PDC
            }
        }
        return null;
    }

    private static String pdc(ItemStack item, NamespacedKey key) {
        if (item == null || item.isEmpty()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        try {
            return meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Rozszerzone API konta karty: PIN i saldo konta osobistego (CARD_ACCOUNT). */
    private void initCard() {
        try {
            Class<?> service = Class.forName("pl.skyrise.bank.bank.BankAccountService");
            Class<?> accountClass = Class.forName("pl.skyrise.bank.model.BankAccount");
            Class<?> typeClass = Class.forName("pl.skyrise.bank.model.BankAccountType");
            Class<?> txClass = Class.forName("pl.skyrise.bank.bank.BankAccountService$CardTransaction");

            bankAccounts = bankPlugin.getClass().getMethod("bankAccounts").invoke(bankPlugin);
            personalType = typeClass.getField("PERSONAL").get(null);
            findAccountMethod = service.getMethod("find", UUID.class, typeClass);
            hasPinMethod = accountClass.getMethod("hasPin");
            verifyPinMethod = service.getMethod("verifyPin", accountClass, String.class);
            cardWithdrawMethod = service.getMethod("cardWithdraw", UUID.class, BigDecimal.class);
            cardDepositMethod = service.getMethod("cardDeposit", UUID.class, String.class, BigDecimal.class);
            cardTxSuccess = txClass.getMethod("success");
            cardTxBalance = txClass.getMethod("balance");
            cardTxError = txClass.getMethod("error");
            cardReady = bankAccounts != null && personalType != null;
        } catch (Throwable t) {
            cardReady = false;
            plugin.getLogger().warning("Brak API konta karty (PIN) w SkyRiseBank: " + t.getClass().getSimpleName());
        }
    }

    public boolean cardReady() {
        return cardReady;
    }

    /** Długość PIN-u ustawiona w configu SkyRiseBank (banking.pin.length). */
    public int pinLength() {
        return bankPinLength;
    }

    /** Sprawdza PIN karty względem konta osobistego gracza. Wynik na głównym wątku. */
    public void verifyPin(Player player, String pin, Consumer<PinResult> callback) {
        if (!cardReady) {
            callback.accept(PinResult.ERROR);
            return;
        }
        try {
            Object future = findAccountMethod.invoke(bankAccounts, player.getUniqueId(), personalType);
            if (!(future instanceof CompletableFuture<?> cf)) {
                callback.accept(PinResult.ERROR);
                return;
            }
            cf.whenComplete((result, error) -> onMain(() -> callback.accept(checkPin(result, error, pin))));
        } catch (Throwable t) {
            callback.accept(PinResult.ERROR);
        }
    }

    private PinResult checkPin(Object result, Throwable error, String pin) {
        if (error != null || result == null) return PinResult.ERROR;
        try {
            if (!(result instanceof Optional<?> opt) || opt.isEmpty()) return PinResult.NO_ACCOUNT;
            Object account = opt.get();
            Object hasPin = hasPinMethod.invoke(account);
            if (!(hasPin instanceof Boolean b) || !b) return PinResult.NO_PIN;
            Object verified = verifyPinMethod.invoke(bankAccounts, account, pin);
            return verified instanceof Boolean ok && ok ? PinResult.OK : PinResult.WRONG;
        } catch (Throwable t) {
            return PinResult.ERROR;
        }
    }

    /** Pobiera kwotę z konta karty (już po weryfikacji PIN-u). */
    public void cardWithdraw(Player player, double amount, Consumer<ChargeResult> callback) {
        if (!cardReady || amount <= 0) {
            callback.accept(new ChargeResult(false, "ERROR", 0));
            return;
        }
        try {
            Object future = cardWithdrawMethod.invoke(bankAccounts, player.getUniqueId(), money(amount));
            if (!(future instanceof CompletableFuture<?> cf)) {
                callback.accept(new ChargeResult(false, "ERROR", 0));
                return;
            }
            cf.whenComplete((result, error) -> {
                ChargeResult parsed = parseCardTransaction(result, error);
                onMain(() -> callback.accept(parsed));
            });
        } catch (Throwable t) {
            callback.accept(new ChargeResult(false, "ERROR", 0));
        }
    }

    private ChargeResult parseCardTransaction(Object result, Throwable error) {
        if (error != null || result == null) return new ChargeResult(false, "ERROR", 0);
        try {
            Object success = cardTxSuccess.invoke(result);
            boolean ok = success instanceof Boolean b && b;
            Object balance = cardTxBalance.invoke(result);
            double value = balance instanceof BigDecimal bd ? bd.doubleValue() : 0;
            if (ok) return new ChargeResult(true, "SUCCESS", value);
            Object message = cardTxError.invoke(result);
            String text = message == null ? "" : String.valueOf(message);
            String lower = text.toLowerCase(Locale.ROOT);
            String status;
            if (lower.contains("limit") || lower.contains("mało") || lower.contains("środk")) {
                status = "INSUFFICIENT_FUNDS";
            } else if (lower.contains("konta")) {
                status = "NO_ACCOUNT";
            } else {
                status = "ERROR";
            }
            return new ChargeResult(false, status, value);
        } catch (Throwable t) {
            return new ChargeResult(false, "ERROR", 0);
        }
    }

    /** Zwrot na konto karty, gdy wydanie przedmiotów nie doszło do skutku. */
    public void cardRefund(UUID uuid, double amount) {
        if (!cardReady || amount <= 0) return;
        try {
            // Konto musi istnieć (PIN był zweryfikowany); drugi argument jest użyty tylko przy jego tworzeniu.
            cardDepositMethod.invoke(bankAccounts, uuid, "SkyRiseSklep - zwrot", money(amount));
        } catch (Throwable ignored) {
            // zwrot nie może zepsuć płatności
        }
    }

    // ------------------------------------------------------------- OPERACJE API

    public boolean isFrozen(UUID uuid) {
        if (!available || isFrozenMethod == null) return false;
        try {
            Object value = isFrozenMethod.invoke(api, uuid);
            return value instanceof Boolean b && b;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Saldo z cache banku; null, gdy konto nie jest jeszcze w pamięci. */
    public Double cachedBalance(UUID uuid) {
        if (!available || cachedBalanceMethod == null) return null;
        try {
            Object value = cachedBalanceMethod.invoke(api, uuid);
            if (value instanceof Optional<?> opt && opt.orElse(null) instanceof BigDecimal bd) return bd.doubleValue();
        } catch (Throwable ignored) {
            // brak cache
        }
        return null;
    }

    public String balanceText(Player player) {
        Double balance = cachedBalance(player.getUniqueId());
        return balance == null ? "nieznane saldo" : format(balance);
    }

    /** Pobiera kwotę z konta gracza. Callback zawsze wołany na głównym wątku. */
    public void withdraw(Player player, double amount, Consumer<ChargeResult> callback) {
        if (!available || amount <= 0) {
            callback.accept(new ChargeResult(false, "NO_API", 0));
            return;
        }
        try {
            Object future = withdrawMethod.invoke(api, player.getUniqueId(), money(amount), plugin.settings().bankReason);
            if (!(future instanceof CompletableFuture<?> cf)) {
                callback.accept(new ChargeResult(false, "ERROR", 0));
                return;
            }
            cf.whenComplete((result, error) -> {
                ChargeResult parsed = parseResult(result, error);
                onMain(() -> callback.accept(parsed));
            });
        } catch (Throwable t) {
            callback.accept(new ChargeResult(false, "ERROR", 0));
        }
    }

    /** Zwraca środki / przekazuje podatek na konto odbiorcy. */
    public void deposit(UUID uuid, double amount, String reason, Consumer<Boolean> callback) {
        if (!available || amount <= 0) {
            if (callback != null) callback.accept(false);
            return;
        }
        try {
            Object future = depositMethod.invoke(api, uuid, money(amount), reason);
            if (!(future instanceof CompletableFuture<?> cf)) {
                if (callback != null) callback.accept(false);
                return;
            }
            cf.whenComplete((result, error) -> {
                boolean ok = error == null && result != null && successOf(result);
                if (callback != null) onMain(() -> callback.accept(ok));
            });
        } catch (Throwable t) {
            if (callback != null) callback.accept(false);
        }
    }

    /** Przelew podatku na nick z tax.receiver. */
    public boolean depositToName(String playerName, double amount) {
        if (!available || playerName == null || playerName.isBlank() || amount <= 0) return false;
        try {
            UUID uuid = Bukkit.getOfflinePlayer(playerName).getUniqueId();
            deposit(uuid, amount, "SkyRiseSklep - podatek", null);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private ChargeResult parseResult(Object result, Throwable error) {
        if (error != null || result == null) return new ChargeResult(false, "ERROR", 0);
        try {
            boolean success = successOf(result);
            Object status = resultStatus.invoke(result);
            Object balance = resultBalance.invoke(result);
            double value = balance instanceof BigDecimal bd ? bd.doubleValue() : 0;
            return new ChargeResult(success, status == null ? "ERROR" : String.valueOf(status), value);
        } catch (Throwable t) {
            return new ChargeResult(false, "ERROR", 0);
        }
    }

    private boolean successOf(Object result) {
        if (resultSuccess == null) return false;
        try {
            Object value = resultSuccess.invoke(result);
            return value instanceof Boolean b && b;
        } catch (Throwable t) {
            return false;
        }
    }

    private static BigDecimal money(double amount) {
        return BigDecimal.valueOf(amount).setScale(2, RoundingMode.HALF_UP);
    }

    private void onMain(Runnable runnable) {
        if (!plugin.isEnabled()) return;
        try {
            Bukkit.getScheduler().runTask(plugin, runnable);
        } catch (Throwable ignored) {
            // plugin już wyłączony
        }
    }

    private static Method find(Class<?> clazz, String name, int params) {
        for (Method method : clazz.getMethods()) {
            if (method.getName().equals(name) && method.getParameterCount() == params) return method;
        }
        return null;
    }
}
