package pl.skyrise.sklep;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Locale;

/** Pomocnicze metody: kolory, gradient, placeholdery, nazwy itemów, liczby. */
public final class Util {

    private Util() {
    }

    /**
     * Kolory legacy (&) + zawsze wyłączona kursywa, dzięki czemu wszystkie
     * napisy na itemach są proste (niepochyłe).
     */
    public static Component color(String text) {
        if (text == null) return Component.empty();
        return LegacyComponentSerializer.legacyAmpersand()
                .deserialize(text.replace('§', '&'))
                .decoration(TextDecoration.ITALIC, false);
    }

    /** Płynny gradient między dwoma kolorami hex, znak po znaku. */
    public static Component gradient(String text, String fromHex, String toHex) {
        if (text == null || text.isEmpty()) return Component.empty();
        TextColor from = TextColor.fromHexString(fromHex);
        TextColor to = TextColor.fromHexString(toHex);
        if (from == null || to == null) return Component.text(text);

        TextComponent.Builder builder = Component.text();
        int steps = Math.max(1, text.length() - 1);
        for (int i = 0; i < text.length(); i++) {
            float t = (float) i / steps;
            int r = Math.round(from.red() + (to.red() - from.red()) * t);
            int g = Math.round(from.green() + (to.green() - from.green()) * t);
            int b = Math.round(from.blue() + (to.blue() - from.blue()) * t);
            builder.append(Component.text(String.valueOf(text.charAt(i)))
                    .color(TextColor.color(clamp(r), clamp(g), clamp(b))));
        }
        return builder.build().decoration(TextDecoration.ITALIC, false);
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    public static String plain(Component component) {
        if (component == null) return "";
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static String replace(String text, String... kv) {
        if (text == null) return "";
        String out = text;
        for (int i = 0; i + 1 < kv.length; i += 2) {
            String value = kv[i + 1] == null ? "" : kv[i + 1];
            out = out.replace("{" + kv[i] + "}", value);
        }
        return out;
    }

    public static String itemName(ItemStack item) {
        if (item == null || item.isEmpty()) return "powietrze";
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) return plain(meta.displayName());
        return item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    /** Akceptuje "12.50" oraz "12,50". */
    public static Double parseNumber(String raw) {
        if (raw == null) return null;
        String s = raw.trim().replace(" ", "").replace(",", ".");
        if (s.isEmpty()) return null;
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
