package pl.skyrise.sklep;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** data.yml: punkty koszyka, zapisany item koszyka i wszystkie regały. */
public final class DataStore {

    private final SkyRiseSklep plugin;
    private final File file;
    private final Map<String, Shelf> shelves = new LinkedHashMap<>();
    private final Set<String> basketPoints = new LinkedHashSet<>();
    private final Set<String> checkoutPoints = new LinkedHashSet<>();
    private final Map<UUID, List<CartEntry>> carts = new ConcurrentHashMap<>();
    private final List<Promotion> promotions = new ArrayList<>();
    private long promoLastRotation = 0;
    private String basketItemBase64 = "";

    public DataStore(SkyRiseSklep plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        shelves.clear();
        basketPoints.clear();
        checkoutPoints.clear();
        carts.clear();
        promotions.clear();
        promoLastRotation = 0;
        basketItemBase64 = "";

        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        if (!file.exists()) {
            save();
            return;
        }

        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        basketItemBase64 = y.getString("basket-item", "");
        promoLastRotation = y.getLong("promotion-last-rotation", 0L);
        basketPoints.addAll(y.getStringList("basket-points"));
        checkoutPoints.addAll(y.getStringList("checkout-points"));

        ConfigurationSection root = y.getConfigurationSection("shelves");
        if (root != null) {
            for (String name : root.getKeys(false)) {
                ConfigurationSection s = root.getConfigurationSection(name);
                if (s == null) continue;
                Shelf shelf = new Shelf(name);
                shelf.targets.addAll(s.getStringList("targets"));
                if (s.isSet("default-price")) shelf.defaultPrice = s.getDouble("default-price");

                ConfigurationSection items = s.getConfigurationSection("items");
                if (items != null) {
                    for (String k : items.getKeys(false)) {
                        try {
                            int slot = Integer.parseInt(k);
                            ItemStack item = decode(items.getString(k, ""));
                            if (item != null && !item.isEmpty()) shelf.items.put(slot, item);
                        } catch (NumberFormatException ignored) {
                            // pomiń błędny klucz
                        }
                    }
                }

                ConfigurationSection prices = s.getConfigurationSection("prices");
                if (prices != null) {
                    for (String k : prices.getKeys(false)) {
                        try {
                            int slot = Integer.parseInt(k);
                            shelf.prices.put(slot, prices.getDouble(k));
                        } catch (NumberFormatException ignored) {
                            // pomiń błędny klucz
                        }
                    }
                }
                shelves.put(key(name), shelf);
            }
        }

        for (Map<?, ?> raw : y.getMapList("promotions")) {
            try {
                Object shelf = raw.get("shelf");
                Object slot = raw.get("slot");
                Object percent = raw.get("percent");
                Object expires = raw.get("expires");
                Object auto = raw.get("auto");
                if (shelf == null || slot == null) continue;
                promotions.add(new Promotion(
                        String.valueOf(shelf),
                        slot instanceof Number n ? n.intValue() : Integer.parseInt(String.valueOf(slot)),
                        percent instanceof Number n ? n.intValue() : 0,
                        expires instanceof Number n ? n.longValue() : 0L,
                        Boolean.parseBoolean(String.valueOf(auto))));
            } catch (RuntimeException ignored) {
                // błędny wpis promocji - pomiń
            }
        }

        ConfigurationSection cartsRoot = y.getConfigurationSection("carts");
        if (cartsRoot != null) {
            for (String uuidText : cartsRoot.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidText);
                    List<CartEntry> entries = new ArrayList<>();
                    for (Map<?, ?> raw : cartsRoot.getMapList(uuidText + ".items")) {
                        Object item = raw.get("item");
                        Object amount = raw.get("amount");
                        Object price = raw.get("price");
                        Object data = raw.get("data");
                        if (item == null) continue;
                        entries.add(new CartEntry(
                                String.valueOf(item),
                                amount instanceof Number n ? n.intValue() : 1,
                                price instanceof Number n ? n.doubleValue() : 0.0,
                                data == null ? "" : String.valueOf(data)));
                    }
                    carts.put(uuid, entries);
                } catch (IllegalArgumentException ignored) {
                    // błędny UUID w pliku - pomiń
                }
            }
        }
    }

    public void save() {
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();

        YamlConfiguration y = new YamlConfiguration();
        y.set("basket-item", basketItemBase64 == null ? "" : basketItemBase64);
        y.set("promotion-last-rotation", promoLastRotation);
        y.set("basket-points", new ArrayList<>(basketPoints));
        y.set("checkout-points", new ArrayList<>(checkoutPoints));

        for (Shelf shelf : shelves.values()) {
            String base = "shelves." + shelf.name + ".";
            y.set(base + "targets", new ArrayList<>(shelf.targets));
            if (shelf.defaultPrice != null) y.set(base + "default-price", shelf.defaultPrice);
            for (Map.Entry<Integer, ItemStack> e : shelf.items.entrySet()) {
                String b64 = encode(e.getValue());
                if (b64 != null) y.set(base + "items." + e.getKey(), b64);
            }
            for (Map.Entry<Integer, Double> e : shelf.prices.entrySet()) {
                y.set(base + "prices." + e.getKey(), e.getValue());
            }
        }

        for (Map.Entry<UUID, List<CartEntry>> e : carts.entrySet()) {
            List<Map<String, Object>> serialized = new ArrayList<>();
            for (CartEntry entry : e.getValue()) {
                Map<String, Object> map = new LinkedHashMap<>();
                map.put("item", entry.item());
                map.put("amount", entry.amount());
                map.put("price", entry.price());
                map.put("data", entry.itemBase64() == null ? "" : entry.itemBase64());
                serialized.add(map);
            }
            y.set("carts." + e.getKey() + ".items", serialized);
        }

        List<Map<String, Object>> promoSerialized = new ArrayList<>();
        for (Promotion promotion : promotions) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("shelf", promotion.shelf());
            map.put("slot", promotion.slot());
            map.put("percent", promotion.percent());
            map.put("expires", promotion.expiresAt());
            map.put("auto", promotion.automatic());
            promoSerialized.add(map);
        }
        y.set("promotions", promoSerialized);
        try {
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Nie udało się zapisać data.yml: " + e.getMessage());
        }
    }

    public static String encode(ItemStack item) {
        if (item == null || item.isEmpty()) return null;
        try {
            return Base64.getEncoder().encodeToString(item.serializeAsBytes());
        } catch (Throwable t) {
            return null;
        }
    }

    public static ItemStack decode(String b64) {
        if (b64 == null || b64.isBlank()) return null;
        try {
            return ItemStack.deserializeBytes(Base64.getDecoder().decode(b64));
        } catch (Throwable t) {
            return null;
        }
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public Shelf getShelf(String name) {
        return name == null ? null : shelves.get(key(name));
    }

    public void addShelf(Shelf shelf) {
        shelves.put(key(shelf.name), shelf);
    }

    public void removeShelf(String name) {
        shelves.remove(key(name));
    }

    public Collection<Shelf> all() {
        return shelves.values();
    }

    public Shelf findShelfByTarget(String target) {
        for (Shelf shelf : shelves.values()) {
            if (shelf.targets.contains(target)) return shelf;
        }
        return null;
    }

    /**
     * Regał otwiera się też po kliknięciu bloku w promieniu radius w każdą stronę.
     * Tylko dla klików w blok; encje (meble Nexo) nadal reagują na dokładny punkt.
     */
    public Shelf findShelfNear(String target, int radius) {
        if (radius <= 0) return null;
        Location from = Targets.locationOf(target);
        if (from == null || from.getWorld() == null) return null;
        for (Shelf shelf : shelves.values()) {
            for (String candidate : shelf.targets) {
                Location to = Targets.locationOf(candidate);
                if (to == null || to.getWorld() == null) continue;
                if (!to.getWorld().equals(from.getWorld())) continue;
                if (Targets.blockDistance(from, to) <= radius) return shelf;
            }
        }
        return null;
    }

    public Set<String> basketPoints() {
        return basketPoints;
    }

    public Set<String> checkoutPoints() {
        return checkoutPoints;
    }

    public String basketItemBase64() {
        return basketItemBase64;
    }

    public void setBasketItemBase64(String value) {
        this.basketItemBase64 = value == null ? "" : value;
    }

    public List<CartEntry> getCart(UUID uuid) {
        List<CartEntry> list = carts.get(uuid);
        return list == null ? new ArrayList<>() : new ArrayList<>(list);
    }

    public void setCart(UUID uuid, List<CartEntry> entries) {
        carts.put(uuid, new ArrayList<>(entries));
    }

    public void clearCart(UUID uuid) {
        carts.remove(uuid);
    }

    public List<Promotion> promotions() {
        return new ArrayList<>(promotions);
    }

    public void setPromotions(List<Promotion> list) {
        promotions.clear();
        if (list != null) promotions.addAll(list);
    }

    public long promoLastRotation() {
        return promoLastRotation;
    }

    public void setPromoLastRotation(long value) {
        promoLastRotation = value;
    }
}
