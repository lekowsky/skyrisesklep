package pl.skyrise.sklep;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Zawartość koszyka + scoreboard. Domyślnie scoreboard jest wyłączony
 * (cart.enabled: false), ale pojawia się przy wzięciu koszyka i znika po
 * zakupie. Można go też przełączać ręcznie komendą /srs widok.
 */
public final class CartManager {

    private final SkyRiseSklep plugin;
    private final Set<UUID> visible = ConcurrentHashMap.newKeySet();

    public CartManager(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    private boolean active() {
        Settings s = plugin.settings();
        return s.cartEnabled || s.cartShowOnBasket || s.cartToggleCommand;
    }

    /** Stan domyślny: przy wejściu na serwer i po reloadzie. */
    public void applyDefault(Player player) {
        if (!active()) {
            hide(player);
            return;
        }
        Settings s = plugin.settings();
        if (s.cartEnabled || (s.cartShowOnBasket && plugin.baskets().hasBasket(player))) {
            show(player);
        } else {
            hide(player);
        }
    }

    /** Wywoływane w momencie otrzymania koszyka. */
    public void start(Player player) {
        if (!active()) return;
        Settings s = plugin.settings();
        if (s.cartClearOnNewBasket) {
            plugin.data().clearCart(player.getUniqueId());
            plugin.data().save();
        }
        if (s.cartEnabled || s.cartShowOnBasket) show(player);
        else hide(player);
    }

    /** Dodaje przedmiot do koszyka. Zwraca false, gdy nie udało się zapisać itemu. */
    public boolean add(Player player, ItemStack item, int amount, double price) {
        if (!active()) return true;
        ItemStack single = item.clone();
        single.setAmount(1);
        String encoded = DataStore.encode(single);
        if (encoded == null) return false;

        String name = Util.itemName(item);
        List<CartEntry> updated = new ArrayList<>();
        boolean merged = false;
        for (CartEntry entry : plugin.data().getCart(player.getUniqueId())) {
            if (entry.itemBase64().equals(encoded)) {
                updated.add(new CartEntry(name, entry.amount() + amount, entry.price() + price, encoded));
                merged = true;
            } else {
                updated.add(entry);
            }
        }
        if (!merged) updated.add(new CartEntry(name, amount, price, encoded));
        plugin.data().setCart(player.getUniqueId(), updated);
        plugin.data().save();
        refresh(player);
        return true;
    }

    public void clear(Player player) {
        plugin.data().clearCart(player.getUniqueId());
        plugin.data().save();
        refresh(player);
    }

    /** Usuwa całą pozycję z koszyka. Zwraca usuniętą pozycję albo null. */
    public CartEntry removeLine(Player player, String itemBase64) {
        List<CartEntry> updated = new ArrayList<>();
        CartEntry removed = null;
        for (CartEntry entry : plugin.data().getCart(player.getUniqueId())) {
            if (removed == null && entry.itemBase64().equals(itemBase64)) removed = entry;
            else updated.add(entry);
        }
        if (removed == null) return null;
        plugin.data().setCart(player.getUniqueId(), updated);
        plugin.data().save();
        refresh(player);
        return removed;
    }

    /** Usuwa jedną sztukę z pozycji; przy ostatniej sztuce znika cała pozycja. */
    public boolean removeOne(Player player, String itemBase64) {
        List<CartEntry> updated = new ArrayList<>();
        boolean changed = false;
        for (CartEntry entry : plugin.data().getCart(player.getUniqueId())) {
            if (!changed && entry.itemBase64().equals(itemBase64)) {
                changed = true;
                int amount = Math.max(1, entry.amount());
                if (amount <= 1) continue;
                double unit = entry.price() / amount;
                double price = Math.round(unit * (amount - 1) * 100.0) / 100.0;
                updated.add(new CartEntry(entry.item(), amount - 1, price, entry.itemBase64()));
            } else {
                updated.add(entry);
            }
        }
        if (!changed) return false;
        plugin.data().setCart(player.getUniqueId(), updated);
        plugin.data().save();
        refresh(player);
        return true;
    }

    /** Pełny reset: czyści zawartość i chowa scoreboard (koszyk oddany/zabrany). */
    public void reset(Player player) {
        plugin.data().clearCart(player.getUniqueId());
        plugin.data().save();
        hide(player);
    }

    /** Koniec zakupów: czyści dane i chowa scoreboard, jeśli tak ustawiono. */
    public void finish(Player player) {
        plugin.data().clearCart(player.getUniqueId());
        plugin.data().save();
        afterPurchase(player);
    }

    public void afterPurchase(Player player) {
        if (plugin.settings().cartHideAfterPurchase) hide(player);
        else refresh(player);
    }

    /** Ręczne przełączanie: /srs widok */
    public void toggle(Player player) {
        if (!plugin.settings().cartToggleCommand) {
            plugin.messages().send(player, "cart-toggle-disabled");
            return;
        }
        if (!active()) {
            hide(player);
            plugin.messages().send(player, "cart-hidden");
            return;
        }
        if (visible.contains(player.getUniqueId())) {
            hide(player);
            plugin.messages().send(player, "cart-hidden");
        } else {
            show(player);
            plugin.messages().send(player, "cart-shown");
        }
    }

    public void show(Player player) {
        visible.add(player.getUniqueId());
        refresh(player);
    }

    public void hide(Player player) {
        if (player == null) return;
        visible.remove(player.getUniqueId());
        plugin.tab().hide(player);
    }

    public void refresh(Player player) {
        if (!active() || player == null || !player.isOnline()) return;
        if (!visible.contains(player.getUniqueId())) return;
        plugin.tab().show(player, plugin.settings().cartTitle,
                buildLines(plugin.data().getCart(player.getUniqueId())));
    }

    public List<CartEntry> entries(Player player) {
        return plugin.data().getCart(player.getUniqueId());
    }

    public double total(List<CartEntry> entries) {
        double total = 0;
        for (CartEntry entry : entries) total += entry.price();
        return total;
    }

    /** Rozbija pozycję koszyka na stacki gotowe do wydania. */
    public List<ItemStack> expand(CartEntry entry) {
        List<ItemStack> stacks = new ArrayList<>();
        ItemStack base = DataStore.decode(entry.itemBase64());
        if (base == null || base.isEmpty()) return stacks;
        int remaining = Math.max(1, entry.amount());
        int max = Math.max(1, base.getMaxStackSize());
        while (remaining > 0) {
            int size = Math.min(max, remaining);
            ItemStack stack = base.clone();
            stack.setAmount(size);
            stacks.add(stack);
            remaining -= size;
        }
        return stacks;
    }

    private List<String> buildLines(List<CartEntry> entries) {
        Settings s = plugin.settings();
        List<String> lines = new ArrayList<>();
        for (int i = 0; i < s.cartBlankLines; i++) lines.add(" ");

        if (entries.isEmpty()) {
            lines.add(s.cartEmptyLine);
            return lines;
        }

        // TAB wyświetla maksymalnie 15 linii: miejsce na pauzy, "... i jeszcze" oraz sumę.
        int room = Math.max(1, 15 - s.cartBlankLines - 2);
        int shown = Math.min(entries.size(), Math.min(s.cartMaxItems, room));
        for (int i = 0; i < shown; i++) {
            CartEntry entry = entries.get(i);
            lines.add(Util.replace(s.cartItemLine,
                    "amount", String.valueOf(entry.amount()),
                    "item", entry.item(),
                    "price", plugin.economy().format(entry.price())));
        }
        if (entries.size() > shown) {
            lines.add(Util.replace(s.cartMoreLine, "count", String.valueOf(entries.size() - shown)));
        }
        lines.add(Util.replace(s.cartTotalLine, "total", plugin.economy().format(total(entries))));
        return lines;
    }
}
