package pl.skyrise.sklep;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Jedno losowanie dziennie o ustalonej godzinie (domyślnie 6:00). Kandydaci
 * pochodzą ze WSZYSTKICH ustawionych regałów, liczba ofert i rabat są losowe,
 * a promocje wygasają wraz z kolejnym losowaniem. Bez udziału administratora.
 */
public final class PromotionManager {

    private record Lucky(int percent, long expiresAt) {
    }

    private final SkyRiseSklep plugin;
    private final Map<String, Promotion> active = new ConcurrentHashMap<>();
    private final Map<UUID, Lucky> lucky = new ConcurrentHashMap<>();
    private BukkitTask task;
    private long lastRotation = 0;

    public PromotionManager(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ CYKL

    public void reload() {
        active.clear();
        lucky.clear();
        long now = System.currentTimeMillis();
        if (plugin.settings().promoPersist) {
            for (Promotion promotion : plugin.data().promotions()) {
                if (promotion == null || promotion.expired(now)) continue;
                active.put(promotion.key(), promotion);
            }
        }
        lastRotation = plugin.data().promoLastRotation();
    }

    public void start() {
        stop();
        if (!plugin.settings().promoEnabled) return;
        long ticks = 20L * Math.max(1, plugin.settings().promoCheckSeconds);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, ticks, ticks);
        // Pierwsze sprawdzenie zaraz po starcie (serwer mógł być wyłączony o 6:00).
        Bukkit.getScheduler().runTaskLater(plugin, this::tick, 20L);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        Settings s = plugin.settings();
        if (!s.promoEnabled) return;
        long now = System.currentTimeMillis();
        purge(now);
        if (!"AUTO".equalsIgnoreCase(s.promoMode)) return;

        if (!dayAllowed()) {
            if (clearAutomatic()) {
                sync();
                announce("promo-end");
            }
            return;
        }

        LocalTime at = dailyAt();
        long dueToday = dueMillis(LocalDate.now().atTime(at));
        boolean scheduled = now >= dueToday && lastRotation < dueToday;
        // lastRotation == 0: pierwsze uruchomienie - losuj od razu, bez czekania do 6:00.
        if (lastRotation == 0 || scheduled) {
            rotate(now, nextDueMillis(at), true);
        }
    }

    private void purge(long now) {
        boolean changed = false;
        for (Map.Entry<String, Promotion> e : active.entrySet()) {
            if (e.getValue().expired(now)) {
                active.remove(e.getKey());
                changed = true;
            }
        }
        for (Map.Entry<UUID, Lucky> e : lucky.entrySet()) {
            if (e.getValue().expiresAt() <= now) {
                lucky.remove(e.getKey());
                changed = true;
            }
        }
        if (changed) sync();
    }

    /** Ręczne „losuj teraz" z panelu - ta sama tura, bez zmiany pory dnia. */
    public int rotateNow() {
        if (!plugin.settings().promoEnabled) {
            plugin.messages().broadcast("promo-disabled");
            return 0;
        }
        clearAutomatic();
        return rotate(System.currentTimeMillis(), nextDueMillis(dailyAt()), true);
    }

    /** Losuje liczbę ofert, przedmioty ze wszystkich regałów i rabaty. */
    private int rotate(long now, long expires, boolean announce) {
        Settings s = plugin.settings();

        // Każdy ustawiony regał ma własną pulę slotów - żaden nie jest pominięty.
        Map<String, List<String>> byShelf = new LinkedHashMap<>();
        for (Shelf shelf : plugin.data().all()) {
            List<String> slots = new ArrayList<>();
            for (int slot = 0; slot < GuiManager.ITEM_SLOTS; slot++) {
                ItemStack item = shelf.items.get(slot);
                if (item == null || item.isEmpty()) continue;
                Promotion existing = active.get(shelf.name + "|" + slot);
                if (existing != null && !existing.automatic()) continue; // nie ruszamy ręcznych
                slots.add(shelf.name + "|" + slot);
            }
            if (slots.isEmpty()) continue;
            Collections.shuffle(slots);
            byShelf.put(shelf.name, slots);
        }
        if (byShelf.isEmpty()) {
            lastRotation = now;
            sync();
            return 0;
        }

        int wanted = randomInt(s.promoAutoMinItems, s.promoAutoMaxItems);
        if (s.promoAllShelves) {
            wanted = Math.max(wanted, Math.min(byShelf.size(), s.promoAutoMaxItems));
        }

        // Najpierw po jednym przedmiocie z każdego regału, potem dopełnij losowo.
        List<String> picked = new ArrayList<>();
        List<String> rest = new ArrayList<>();
        for (List<String> slots : byShelf.values()) {
            picked.add(slots.get(0));
            if (slots.size() > 1) rest.addAll(slots.subList(1, slots.size()));
        }
        Collections.shuffle(picked);
        Collections.shuffle(rest);
        while (picked.size() > wanted && !picked.isEmpty()) picked.remove(picked.size() - 1);
        List<String> pool = new ArrayList<>(picked);
        pool.addAll(rest);

        int count = Math.min(wanted, pool.size());
        int min = Math.min(s.promoAutoMin, s.promoAutoMax);
        int max = Math.max(s.promoAutoMin, s.promoAutoMax);
        for (int i = 0; i < count; i++) {
            String[] parts = pool.get(i).split("\\|", 2);
            int slot = Integer.parseInt(parts[1]);
            Promotion promotion = new Promotion(parts[0], slot, randomPercent(min, max), expires, true);
            active.put(promotion.key(), promotion);
        }
        lastRotation = now;
        rollLucky(now, expires);
        sync();

        if (announce && count > 0 && s.promoAnnounce) {
            plugin.messages().broadcast("promo-start",
                    "min", String.valueOf(min),
                    "max", String.valueOf(max),
                    "count", String.valueOf(count),
                    "shelves", String.valueOf(byShelf.size()),
                    "until", s.promoDailyAt);
        }
        return count;
    }

    private void rollLucky(long now, long expires) {
        Settings s = plugin.settings();
        if (s.promoLuckyChance <= 0 || s.promoLuckyPercent <= 0) return;
        if (ThreadLocalRandom.current().nextInt(100) >= s.promoLuckyChance) return;
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (online.isEmpty()) return;
        Player player = online.get(ThreadLocalRandom.current().nextInt(online.size()));
        lucky.put(player.getUniqueId(), new Lucky(s.promoLuckyPercent, expires));
        if (s.promoAnnounce) {
            plugin.messages().broadcast("promo-lucky",
                    "player", player.getName(),
                    "percent", String.valueOf(s.promoLuckyPercent),
                    "until", s.promoDailyAt);
        }
    }

    private static int randomInt(int min, int max) {
        int low = Math.max(1, Math.min(min, max));
        int high = Math.max(low, Math.max(min, max));
        return ThreadLocalRandom.current().nextInt(low, high + 1);
    }

    private static int randomPercent(int min, int max) {
        int steps = Math.max(0, (max - min) / 5);
        return Math.min(max, min + ThreadLocalRandom.current().nextInt(steps + 1) * 5);
    }

    private LocalTime dailyAt() {
        try {
            return LocalTime.parse(plugin.settings().promoDailyAt.trim());
        } catch (DateTimeException | NullPointerException e) {
            return LocalTime.of(6, 0);
        }
    }

    /** Puste days = codziennie; wpisane dni ograniczają dni losowania. */
    private boolean dayAllowed() {
        List<String> days = plugin.settings().promoDays;
        if (days.isEmpty()) return true;
        String today = LocalDate.now().getDayOfWeek().name();
        for (String day : days) {
            if (day != null && day.trim().equalsIgnoreCase(today)) return true;
        }
        return false;
    }

    private static long dueMillis(LocalDateTime dateTime) {
        return dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /** Najbliższa godzina losowania: dziś, jeśli jeszcze przed nią, inaczej jutro. */
    private long nextDueMillis(LocalTime at) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime today = now.toLocalDate().atTime(at);
        return dueMillis(now.isBefore(today) ? today : today.plusDays(1));
    }

    // --------------------------------------------------------------- CENY/LORE

    public int percentFor(Player player, String shelf, int slot) {
        Settings s = plugin.settings();
        if (!s.promoEnabled || "OFF".equalsIgnoreCase(s.promoMode)) return 0;
        Promotion promotion = active.get(shelf + "|" + slot);
        int percent = promotion == null ? 0 : promotion.percent();
        if (player != null) {
            Lucky bonus = lucky.get(player.getUniqueId());
            if (bonus != null && bonus.expiresAt() > System.currentTimeMillis()) {
                percent += bonus.percent();
            }
        }
        return Math.max(0, Math.min(95, percent));
    }

    public double apply(Player player, String shelf, int slot, double base) {
        int percent = percentFor(player, shelf, slot);
        if (percent <= 0) return base;
        return Math.round(base * (1.0 - percent / 100.0) * 100.0) / 100.0;
    }

    public List<String> loreFor(Player player, String shelf, int slot, double base) {
        int percent = percentFor(player, shelf, slot);
        if (percent <= 0) return List.of();
        Promotion promotion = active.get(shelf + "|" + slot);
        String left = leftText(player, promotion);
        List<String> out = new ArrayList<>();
        for (String line : plugin.settings().promoLore) {
            out.add(Util.replace(line,
                    "old", plugin.economy().format(base),
                    "price", plugin.economy().format(apply(player, shelf, slot, base)),
                    "percent", String.valueOf(percent),
                    "left", left));
        }
        return out;
    }

    private String leftText(Player player, Promotion promotion) {
        long now = System.currentTimeMillis();
        if (promotion != null) return timeLeft(promotion.expiresAt() - now);
        if (player != null) {
            Lucky bonus = lucky.get(player.getUniqueId());
            if (bonus != null) return timeLeft(bonus.expiresAt() - now);
        }
        return "bonus";
    }

    public static String timeLeft(long millis) {
        if (millis <= 0) return "0s";
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        if (hours > 0) return hours + "h " + minutes + "m";
        if (minutes > 0) return minutes + "m " + secs + "s";
        return secs + "s";
    }

    // --------------------------------------------------------------- OPERACJE

    public Promotion get(String shelf, int slot) {
        return active.get(shelf + "|" + slot);
    }

    public List<Promotion> all() {
        List<Promotion> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Promotion promotion : active.values()) {
            if (!promotion.expired(now)) out.add(promotion);
        }
        out.sort(Comparator.comparingLong(Promotion::expiresAt));
        return out;
    }

    public int countFor(String shelf) {
        int count = 0;
        for (Promotion promotion : active.values()) {
            if (promotion.shelf().equals(shelf)) count++;
        }
        return count;
    }

    public void setManual(String shelf, int slot, int percent, int minutes) {
        long expires = System.currentTimeMillis() + (long) Math.max(1, minutes) * 60_000L;
        active.put(shelf + "|" + slot,
                new Promotion(shelf, slot, Math.max(1, Math.min(95, percent)), expires, false));
        sync();
    }

    public int setManualAll(Shelf shelf, int percent, int minutes) {
        int count = 0;
        for (int slot = 0; slot < GuiManager.ITEM_SLOTS; slot++) {
            ItemStack item = shelf.items.get(slot);
            if (item == null || item.isEmpty()) continue;
            setManual(shelf.name, slot, percent, minutes);
            count++;
        }
        return count;
    }

    public void remove(String shelf, int slot) {
        if (active.remove(shelf + "|" + slot) != null) sync();
    }

    public void clearShelf(String shelf) {
        if (active.keySet().removeIf(key -> key.startsWith(shelf + "|"))) sync();
    }

    public boolean clearAutomatic() {
        return active.values().removeIf(Promotion::automatic);
    }

    public void clearAll() {
        active.clear();
        lucky.clear();
        sync();
    }

    public String status() {
        Settings s = plugin.settings();
        if (!s.promoEnabled) return "wyłączone";
        return s.promoMode.toUpperCase(Locale.ROOT) + " o " + s.promoDailyAt
                + " (" + active.size() + " aktywnych)";
    }

    private void announce(String key) {
        if (plugin.settings().promoAnnounce) plugin.messages().broadcast(key);
    }

    private void sync() {
        plugin.data().setPromoLastRotation(lastRotation);
        plugin.data().setPromotions(plugin.settings().promoPersist
                ? new ArrayList<>(active.values()) : List.of());
        plugin.data().save();
    }
}
