package pl.skyrise.sklep;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Odrzuca zbyt szybkie kliknięcia w GUI. Odrzucenie jest całkowicie ciche. */
public final class ClickGuard {

    private final Map<UUID, Long> last = new ConcurrentHashMap<>();

    public boolean allow(UUID uuid, long cooldownMs) {
        if (uuid == null || cooldownMs <= 0) return true;
        long now = System.currentTimeMillis();
        Long previous = last.get(uuid);
        if (previous != null && now - previous < cooldownMs) return false;
        last.put(uuid, now);
        return true;
    }

    public void forget(UUID uuid) {
        if (uuid != null) last.remove(uuid);
    }

    public void clear() {
        last.clear();
    }
}
