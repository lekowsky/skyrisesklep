package pl.skyrise.sklep;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Panel administracyjny: regały, ceny, punkty i promocje w jednym GUI. */
public final class AdminPanel implements Listener {

    private final SkyRiseSklep plugin;

    public AdminPanel(SkyRiseSklep plugin) {
        this.plugin = plugin;
    }

    public enum View { MAIN, SHELF, PROMOTIONS }

    public static final class AdminHolder implements InventoryHolder {
        private final View view;
        private final String shelf;
        private final List<Promotion> displayed = new ArrayList<>();
        private Inventory inventory;

        AdminHolder(View view, String shelf) {
            this.view = view;
            this.shelf = shelf;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public View view() {
            return view;
        }

        public String shelf() {
            return shelf;
        }

        public List<Promotion> displayed() {
            return displayed;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private boolean admin(Player player) {
        if (player.hasPermission("skyrise.admin")) return true;
        plugin.messages().send(player, "no-permission", "permission", "skyrise.admin");
        player.closeInventory();
        return false;
    }

    /** Przełączenie GUI z wnętrza kliku - bezpieczne dopiero w następnym ticku. */
    private void later(Player player, Runnable action) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) action.run();
        });
    }

    // ------------------------------------------------------------------ WIDOKI

    public void openMain(Player player) {
        if (!admin(player)) return;
        Settings s = plugin.settings();
        AdminHolder holder = new AdminHolder(View.MAIN, null);
        Inventory inv = Bukkit.createInventory(holder, 54, Util.color(s.adminTitle));
        holder.setInventory(inv);
        fill(inv);

        List<Shelf> shelves = new ArrayList<>(plugin.data().all());
        if (shelves.isEmpty()) plugin.messages().send(player, "admin-no-shelves");
        int slot = 0;
        for (Shelf shelf : shelves) {
            if (slot >= GuiManager.ITEM_SLOTS) break;
            int promos = plugin.promotions().countFor(shelf.name);
            inv.setItem(slot++, button(Material.CHEST, "&a" + shelf.name, List.of(
                    "&7Przedmiotów: &f" + shelf.items.size(),
                    "&7Punktów: &f" + shelf.targets.size(),
                    "&7Cen: &f" + shelf.prices.size(),
                    "&7Promocje: &f" + promos,
                    "&7Cena domyślna: &e" + plugin.economy().format(shelf.priceFor(-1, s.defaultPrice)),
                    "&7LPM: &fpanel regału",
                    "&7PPM: &fedytor oferty")));
        }

        inv.setItem(45, button(Material.BOOK, s.adminInfo, infoLines()));
        inv.setItem(47, button(Material.NAME_TAG, s.adminNewShelf, List.of(
                "&7Nazwę wpisz na czacie.", "&7Potem PPM w blok lub mebel.")));
        inv.setItem(48, button(Material.GOLD_INGOT, s.adminPromotions, List.of(
                "&7Aktywne rabaty i losowanie tury.")));
        inv.setItem(49, button(Material.REDSTONE_BLOCK, s.adminReload, List.of(
                "&7Przeładuj config, dane i harmonogram.")));
        inv.setItem(50, button(Material.HOPPER, s.adminBasketPoint, List.of(
                "&7PPM w blok, aby dodać punkt koszyka.")));
        inv.setItem(51, button(Material.GOLD_BLOCK, s.adminCheckoutPoint, List.of(
                "&7PPM w blok, aby dodać kasę.")));
        inv.setItem(53, button(Material.BARRIER, s.adminClose, List.of("&7Zamyka panel.")));
        player.openInventory(inv);
        plugin.sound(player, s.openSound);
    }

    public void openShelf(Player player, String name) {
        if (!admin(player)) return;
        Shelf shelf = plugin.data().getShelf(name);
        if (shelf == null) {
            plugin.messages().send(player, "shelf-missing", "shelf", name);
            later(player, () -> openMain(player));
            return;
        }
        Settings s = plugin.settings();
        AdminHolder holder = new AdminHolder(View.SHELF, shelf.name);
        Inventory inv = Bukkit.createInventory(holder, 54,
                Util.color(Util.replace(s.adminShelfTitle, "shelf", shelf.name)));
        holder.setInventory(inv);
        fill(inv);

        for (int slot = 0; slot < GuiManager.ITEM_SLOTS; slot++) {
            ItemStack base = shelf.items.get(slot);
            if (base == null || base.isEmpty()) continue;
            inv.setItem(slot, shelfItem(player, shelf, base, slot));
        }

        inv.setItem(45, button(Material.CHEST, s.adminEditItems, List.of("&7Otwiera edytor 45 slotów.")));
        inv.setItem(46, button(Material.PAPER, s.adminDefaultPrice, List.of("&7Cena wpisywana na czacie.")));
        inv.setItem(47, button(Material.GOLD_INGOT, s.adminPromoAll, List.of(
                "&7Rabat &f-" + s.promoManualPercent + "% &7na &f" + s.promoManualMinutes + " &7min.",
                "&7dla każdego wypełnionego slotu.")));
        inv.setItem(48, button(Material.BARRIER, s.adminClearPromos, List.of("&7Zdejmuje promocje z tego regału.")));
        inv.setItem(49, button(Material.CLOCK, "&eODŚWIEŻ", List.of("&7Przelicza ceny i rabaty.")));
        inv.setItem(50, button(Material.EMERALD, s.adminAddTarget, List.of("&7PPM w blok, aby dopisać punkt.")));
        inv.setItem(51, button(Material.REDSTONE, s.adminRemoveTarget, List.of("&7PPM w blok, aby odpiąć punkt.")));
        inv.setItem(52, button(Material.TNT, s.adminDeleteShelf, List.of("&cShift+PPM: &7usuń regał bez pytania.")));
        inv.setItem(53, button(Material.ARROW, s.adminBack, List.of("&7Wróć do panelu głównego.")));
        player.openInventory(inv);
        plugin.sound(player, s.openSound);
    }

    public void openPromotions(Player player) {
        if (!admin(player)) return;
        Settings s = plugin.settings();
        AdminHolder holder = new AdminHolder(View.PROMOTIONS, null);
        Inventory inv = Bukkit.createInventory(holder, 54, Util.color(s.adminPromoTitle));
        holder.setInventory(inv);
        fill(inv);

        List<Promotion> promotions = plugin.promotions().all();
        if (promotions.isEmpty()) plugin.messages().send(player, "promo-list-empty");
        int slot = 0;
        for (Promotion promotion : promotions) {
            if (slot >= GuiManager.ITEM_SLOTS) break;
            holder.displayed().add(promotion);
            inv.setItem(slot++, button(Material.GOLD_INGOT,
                    "&a" + promotion.shelf() + " &7#&f" + (promotion.slot() + 1), List.of(
                            "&7Rabat: &a-" + promotion.percent() + "%",
                            "&7Pozostało: &f" + PromotionManager.timeLeft(
                                    promotion.expiresAt() - System.currentTimeMillis()),
                            "&7Źródło: &f" + (promotion.automatic() ? "automatyczna" : "z panelu"),
                            "&7LPM: &cusuń tę promocję")));
        }

        inv.setItem(45, button(Material.EMERALD_BLOCK, s.adminRollNow, List.of(
                "&7Losuje nową turę natychmiast.")));
        inv.setItem(46, button(Material.BARRIER, s.adminClearAll, List.of(
                "&cShift+PPM: &7wyczyść wszystkie promocje.")));
        inv.setItem(47, button(Material.BOOK, s.adminInfo, List.of(
                "&7Tryb: &f" + plugin.promotions().status(),
                "&7Aktywne: &f" + promotions.size(),
                "&7Losowanie: &f" + s.promoDailyAt + " &7(co 24h)",
                "&7Ofert dziennie: &f" + s.promoAutoMinItems + "-" + s.promoAutoMaxItems,
                "&7Regały: &f" + (s.promoAllShelves ? "każdy ma ofertę" : "losowy zbiór"),
                "&7Rabat: &f" + s.promoAutoMin + "-" + s.promoAutoMax + "%",
                "&7Dni: &f" + (s.promoDays.isEmpty() ? "codziennie" : s.promoDays))));
        inv.setItem(53, button(Material.ARROW, s.adminBack, List.of("&7Wróć do panelu głównego.")));
        player.openInventory(inv);
        plugin.sound(player, s.openSound);
    }

    private ItemStack shelfItem(Player player, Shelf shelf, ItemStack base, int slot) {
        ItemStack display = base.clone();
        display.setAmount(Math.max(1, base.getAmount()));
        ItemMeta meta = display.getItemMeta();
        if (meta == null) return display;
        double basePrice = shelf.priceFor(slot, plugin.settings().defaultPrice);
        int percent = plugin.promotions().percentFor(player, shelf.name, slot);
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Util.color("&7Cena: &e" + plugin.economy().format(basePrice)));
        if (percent > 0) {
            lore.add(Util.color("&7Po rabacie: &a" + plugin.economy().format(
                    plugin.promotions().apply(player, shelf.name, slot, basePrice))
                    + " &7(-" + percent + "%)"));
        }
        lore.add(Util.color("&7LPM: &fnadaj promocję"));
        lore.add(Util.color("&7PPM: &fusuń promocję"));
        lore.add(Util.color("&7Shift+LPM: &fcena na czacie"));
        meta.lore(lore);
        display.setItemMeta(meta);
        return display;
    }

    private List<String> infoLines() {
        Settings s = plugin.settings();
        return List.of(
                "&7Regały: &f" + plugin.data().all().size(),
                "&7Punkty koszyka: &f" + plugin.data().basketPoints().size(),
                "&7Kasy: &f" + plugin.data().checkoutPoints().size(),
                "&7Ekonomia: &f" + plugin.economy().status(),
                "&7Promocje: &f" + plugin.promotions().status(),
                "&7Zasięg regału: &f" + s.shelfRadius);
    }

    private void fill(Inventory inv) {
        ItemStack filler = button(plugin.settings().fillerMaterial(), "&8 ", List.of());
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);
    }

    private ItemStack button(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.displayName(Util.color(name));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) lines.add(Util.color(line));
        meta.lore(lines);
        item.setItemMeta(meta);
        return item;
    }

    // ------------------------------------------------------------------ KLIKI

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder raw = event.getView().getTopInventory().getHolder();
        if (!(raw instanceof AdminHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null
                || event.getClickedInventory() != event.getView().getTopInventory()) return;
        if (!admin(player)) return;
        if (event.getSlot() != 53
                && !plugin.clicks().allow(player.getUniqueId(), plugin.settings().guiClickCooldownMs)) return;
        switch (holder.view()) {
            case MAIN -> handleMain(player, event);
            case SHELF -> handleShelf(player, holder, event);
            case PROMOTIONS -> handlePromotions(player, holder, event);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder raw = event.getView().getTopInventory().getHolder();
        if (raw instanceof AdminHolder) event.setCancelled(true);
    }

    private void handleMain(Player player, InventoryClickEvent event) {
        int slot = event.getSlot();
        if (slot >= 0 && slot < GuiManager.ITEM_SLOTS) {
            List<Shelf> shelves = new ArrayList<>(plugin.data().all());
            if (slot >= shelves.size()) return;
            Shelf shelf = shelves.get(slot);
            if (event.isRightClick()) later(player, () -> plugin.gui().openEditor(player, shelf));
            else later(player, () -> openShelf(player, shelf.name));
            return;
        }
        switch (slot) {
            case 47 -> {
                player.closeInventory();
                plugin.listeners().startChat(player, Listeners.ChatType.SHELF_NAME, "", 0);
                plugin.messages().send(player, "admin-shelf-name-prompt");
            }
            case 48 -> later(player, () -> openPromotions(player));
            case 49 -> {
                plugin.reloadAll();
                plugin.messages().send(player, "reloaded");
                later(player, () -> openMain(player));
            }
            case 50 -> {
                player.closeInventory();
                plugin.listeners().select(player, Listeners.SelectionType.BASKET_ADD, null, "selection-basket-add");
            }
            case 51 -> {
                player.closeInventory();
                plugin.listeners().select(player, Listeners.SelectionType.CHECKOUT_ADD, null, "selection-checkout-add");
            }
            case 53 -> player.closeInventory();
            default -> {
                // slot informacyjny / wypełniacz
            }
        }
    }

    private void handleShelf(Player player, AdminHolder holder, InventoryClickEvent event) {
        Shelf shelf = plugin.data().getShelf(holder.shelf());
        if (shelf == null) {
            later(player, () -> openMain(player));
            return;
        }
        Settings s = plugin.settings();
        int slot = event.getSlot();
        if (slot >= 0 && slot < GuiManager.ITEM_SLOTS) {
            ItemStack base = shelf.items.get(slot);
            if (base == null || base.isEmpty()) return;
            if (event.isShiftClick() && event.isLeftClick()) {
                player.closeInventory();
                plugin.listeners().startChat(player, Listeners.ChatType.PRICE, shelf.name, slot);
                plugin.messages().send(player, "price-prompt",
                        "shelf", shelf.name, "slot", String.valueOf(slot + 1));
            } else if (event.isRightClick()) {
                plugin.promotions().remove(shelf.name, slot);
                plugin.messages().send(player, "promo-removed",
                        "shelf", shelf.name, "slot", String.valueOf(slot + 1));
                later(player, () -> openShelf(player, shelf.name));
            } else {
                plugin.promotions().setManual(shelf.name, slot, s.promoManualPercent, s.promoManualMinutes);
                plugin.messages().send(player, "promo-manual-set",
                        "shelf", shelf.name, "slot", String.valueOf(slot + 1),
                        "percent", String.valueOf(s.promoManualPercent),
                        "minutes", String.valueOf(s.promoManualMinutes));
                later(player, () -> openShelf(player, shelf.name));
            }
            return;
        }
        switch (slot) {
            case 45 -> later(player, () -> plugin.gui().openEditor(player, shelf));
            case 46 -> {
                player.closeInventory();
                plugin.listeners().startChat(player, Listeners.ChatType.DEFAULT_PRICE, shelf.name, 0);
                plugin.messages().send(player, "price-default-prompt", "shelf", shelf.name);
            }
            case 47 -> {
                int count = plugin.promotions().setManualAll(shelf, s.promoManualPercent, s.promoManualMinutes);
                plugin.messages().send(player, "promo-bulk-set",
                        "count", String.valueOf(count),
                        "percent", String.valueOf(s.promoManualPercent),
                        "minutes", String.valueOf(s.promoManualMinutes));
                later(player, () -> openShelf(player, shelf.name));
            }
            case 48 -> {
                plugin.promotions().clearShelf(shelf.name);
                plugin.messages().send(player, "promo-cleared");
                later(player, () -> openShelf(player, shelf.name));
            }
            case 49 -> later(player, () -> openShelf(player, shelf.name));
            case 50 -> {
                player.closeInventory();
                plugin.listeners().select(player, Listeners.SelectionType.SHELF_ADD, shelf.name, "selection-shelf-add");
            }
            case 51 -> {
                player.closeInventory();
                plugin.listeners().select(player, Listeners.SelectionType.SHELF_REMOVE, shelf.name, "selection-shelf-remove");
            }
            case 52 -> {
                if (!event.isShiftClick()) {
                    plugin.messages().send(player, "admin-delete-hint");
                    return;
                }
                plugin.promotions().clearShelf(shelf.name);
                plugin.data().removeShelf(shelf.name);
                plugin.data().save();
                plugin.messages().send(player, "shelf-deleted", "shelf", shelf.name);
                later(player, () -> openMain(player));
            }
            case 53 -> later(player, () -> openMain(player));
            default -> {
                // wypełniacz
            }
        }
    }

    private void handlePromotions(Player player, AdminHolder holder, InventoryClickEvent event) {
        int slot = event.getSlot();
        if (slot >= 0 && slot < GuiManager.ITEM_SLOTS) {
            if (slot >= holder.displayed().size()) return;
            Promotion promotion = holder.displayed().get(slot);
            plugin.promotions().remove(promotion.shelf(), promotion.slot());
            plugin.messages().send(player, "promo-removed",
                    "shelf", promotion.shelf(), "slot", String.valueOf(promotion.slot() + 1));
            later(player, () -> openPromotions(player));
            return;
        }
        switch (slot) {
            case 45 -> {
                int count = plugin.promotions().rotateNow();
                if (count == 0) plugin.messages().send(player, "promo-no-items");
                else plugin.messages().send(player, "promo-rolled", "count", String.valueOf(count));
                later(player, () -> openPromotions(player));
            }
            case 46 -> {
                if (!event.isShiftClick()) {
                    plugin.messages().send(player, "admin-delete-hint");
                    return;
                }
                plugin.promotions().clearAll();
                plugin.messages().send(player, "promo-cleared");
                later(player, () -> openPromotions(player));
            }
            case 53 -> later(player, () -> openMain(player));
            default -> {
                // slot informacyjny
            }
        }
    }
}
